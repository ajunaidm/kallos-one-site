=== Kallos One Model Form ===
Contributors: kallosone
Tags: model, photographer, form, casting, kallos one
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 2.0.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A model sign-up form for photographers. Each form is emailed to you with an "Add to Kallos One" button. Nothing is saved on your website.

== Description ==

Models fill in their details, measurements (cm or inches), look, experience, the shoots they're interested in and when they're available. You get an email with everything, and an Add to Kallos One button that opens the Kallos One app (iPhone, iPad, Mac) with the model filled in for you to check and save.

* Nothing is stored on your website: no database entries, no files.
* Under 18: a parent or guardian must add their details and agree. Comfort levels and adults-only shoot types are never shown to, or accepted from, anyone under 18.
* Works with any theme and page builder: shortcode [kallos_model_form] (WPBakery Text Block, Elementor Shortcode widget, Divi Text/Code module, classic editor) or the Kallos Model Form block.
* Settings › Kallos Model Form: where forms go, studio name, default country, cm or inches, size system (AU/UK/US/EU), which sections to show or require, consent and thank-you wording, privacy page link, button colour.
* Translation-ready (text domain kallos-model-form).

== Installation ==

1. Plugins › Add New › Upload Plugin, choose the zip, Install Now, Activate.
2. Settings › Kallos Model Form: check the email address and your studio name.
3. Add [kallos_model_form] or the Kallos Model Form block to a page.

== Frequently Asked Questions ==

= The emails go to spam =
Your website sends them itself. Install a free SMTP plugin (for example FluentSMTP) so they're sent through your real email account.

= Where do the details go when I tap Add to Kallos One? =
Your website serves a small helper page that opens Kallos One. The details travel after the # in the link, which browsers never send to a website, so the helper page never sees or keeps them.

== Changelog ==

= 2.0.2 =
* Empty fields now look empty: no grey example height, and the date of birth box stays blank until the model taps it.

= 2.0.1 =
* After sending, models always return to the form page with the thank-you message (even when their browser hides the referring page).

= 2.0.0 =
* Works for any photographer: settings for country, units, sizes, sections, wording and colour; translation-ready; block for the WordPress editor; helper page served by your own site.

= 1.1.2 =
* Theme-proof styles for buttons and tick boxes.
