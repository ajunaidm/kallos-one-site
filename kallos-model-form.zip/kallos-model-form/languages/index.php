<?php
// Silence is golden. Translations (.mo files) for the "kallos-model-form" text domain go here.
