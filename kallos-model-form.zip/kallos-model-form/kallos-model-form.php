<?php
/**
 * Plugin Name: Kallos One Model Form
 * Description: A model sign-up form for photographers. Each form sent is emailed to you with an "Add to Kallos One" button. Nothing is saved on the website.
 * Version: 2.2.1
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Made by a Professional Photographer
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: kallos-model-form
 * Domain Path: /languages
 *
 * Add the form with the shortcode [kallos_model_form] (works in every page builder) or the
 * "Kallos Model Form" block. Settings › Kallos Model Form sets where forms go and what they ask.
 */

if (!defined('ABSPATH')) {
    exit;
}

final class Kallos_Model_Form {
    const VERSION = '2.2.1';
    const OPTION = 'kallos_model_form';
    const TD = 'kallos-model-form';
    const MIN_SECONDS = 4; // A person takes longer than this to fill in the form.
    const SIZE_SYSTEMS = ['AU', 'UK', 'US', 'EU'];
    /** Sections a photographer can show or hide. */
    const SECTIONS = ['address', 'measurements', 'look', 'work', 'interests', 'adult', 'availability', 'travel', 'heard', 'message'];

    /** @var array<string,string> */
    private $errors = [];
    /** @var array<string,mixed> */
    private $values = [];

    public static function boot() {
        $self = new self();
        add_action('init', [$self, 'init']);
        add_action('template_redirect', [$self, 'maybe_helper_page'], 0);
        add_action('admin_menu', [$self, 'admin_menu']);
        add_action('admin_init', [$self, 'register_settings']);
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), [$self, 'settings_link']);
    }

    public function init() {
        load_plugin_textdomain(self::TD, false, dirname(plugin_basename(__FILE__)) . '/languages');
        add_shortcode('kallos_model_form', [$this, 'shortcode']);
        $this->register_block();
        $this->maybe_handle();
    }

    // MARK: Settings

    private static function defaults() {
        return [
            'to'            => '',
            'studio'        => '',
            'country'       => '',
            'unit'          => 'cm',
            'size_system'   => 'AU',
            'show'          => array_fill_keys(self::SECTIONS, '1'),
            'require'       => ['measurements' => '1', 'social' => '1', 'interests' => '1', 'availability' => '1', 'suburb' => '1',
                                'address' => '1', 'experience' => '1', 'terms' => '1'],
            'heading'       => '',
            'intro'         => '',
            'address_search' => '1',
            'mapkit_token'  => '',
            'consent'       => '',
            'thanks'        => '',
            'button'        => '',
            'privacy_url'   => '',
            'button_colour' => '#111111',
        ];
    }

    private function settings() {
        $saved = get_option(self::OPTION, []);
        $s = array_merge(self::defaults(), is_array($saved) ? $saved : []);
        // 2.1.0: requirements added later are on unless the photographer turned them off.
        $s['require'] = array_merge(self::defaults()['require'], is_array($s['require']) ? $s['require'] : []);
        // 2.2.1: the 2.1.0/2.2.0 settings page saved them off without showing them; turn them on once.
        if (is_array($saved) && empty($saved['require_fixed'])) {
            foreach (['address', 'experience', 'terms'] as $what) {
                $s['require'][$what] = '1';
            }
        }
        if ('' === $s['heading']) {
            $s['heading'] = __('Model Registration', self::TD);
        }
        if ('' === $s['intro']) {
            /* translators: %s: the studio name */
            $s['intro'] = sprintf(__('Tell us about yourself so we can plan shoots that suit you. Your details are emailed only to %s, never stored on this website and never shared or sold.', self::TD), '' !== $s['studio'] ? $s['studio'] : get_bloginfo('name'));
        }
        if ('' === $s['to']) {
            $s['to'] = get_option('admin_email');
        }
        if ('' === $s['studio']) {
            $s['studio'] = get_bloginfo('name');
        }
        if ('' === $s['button']) {
            $s['button'] = __('Send my details', self::TD);
        }
        if ('' === $s['thanks']) {
            /* translators: %s: the studio name */
            $s['thanks'] = sprintf(__('Thank you! Your details have been sent to %s. We\'ll be in touch.', self::TD), $s['studio']);
        }
        if ('' === $s['consent']) {
            /* translators: %s: the studio name */
            $s['consent'] = sprintf(__('I agree to my details being emailed to %s to contact me about photo shoots. They are not stored on this website.', self::TD), $s['studio']);
        }
        return $s;
    }

    private function shows($section) {
        $s = $this->settings();
        return !empty($s['show'][$section]);
    }

    private function requires($what) {
        $s = $this->settings();
        $section = ['measurements' => 'measurements', 'social' => 'work', 'interests' => 'interests', 'availability' => 'availability',
                    'suburb' => 'address', 'address' => 'address', 'experience' => 'work', 'terms' => 'work'][$what] ?? $what;
        return !empty($s['require'][$what]) && $this->shows($section);
    }

    // MARK: Fields

    /** Plain fields: name => [label, input type, section ('' = always shown)]. */
    private static function fields() {
        return [
            'given'            => [__('First name', self::TD), 'text', ''],
            'middle'           => [__('Middle name', self::TD), 'text', ''],
            'family'           => [__('Last name', self::TD), 'text', ''],
            'nickname'         => [__('Name you go by (if different)', self::TD), 'text', ''],
            'email'            => [__('Email', self::TD), 'email', ''],
            'phone'            => [__('Mobile number', self::TD), 'tel', ''],
            'dob'              => [__('Date of birth', self::TD), 'date', ''],
            'guardian'         => [__("Parent or guardian's name", self::TD), 'text', ''],
            'guardianRelation' => [__('Relationship (e.g. Mother)', self::TD), 'text', ''],
            'guardianPhone'    => [__("Parent or guardian's mobile", self::TD), 'tel', ''],
            'guardianEmail'    => [__("Parent or guardian's email", self::TD), 'email', ''],
            'street'           => [__('Street address', self::TD), 'text', 'address'],
            'suburb'           => [__('Suburb or city', self::TD), 'text', 'address'],
            'state'            => [__('State or region', self::TD), 'text', 'address'],
            'postcode'         => [__('Postcode', self::TD), 'text', 'address'],
            'country'          => [__('Country', self::TD), 'text', 'address'],
            'hair'             => [__('Hair colour', self::TD), 'text', 'look'],
            'eyes'             => [__('Eye colour', self::TD), 'text', 'look'],
            'tattoos'          => [__('Tattoos (where, or "none")', self::TD), 'text', 'look'],
            'piercings'        => [__('Piercings (where, or "none")', self::TD), 'text', 'look'],
            'instagram'        => [__('Instagram', self::TD), 'text', 'work'],
            'portfolio'        => [__('Portfolio link', self::TD), 'url', 'work'],
            'agency'           => [__('Agency (if any)', self::TD), 'text', 'work'],
            'travel'           => [__('How far can you travel?', self::TD), 'text', 'travel'],
            'heard'            => [__('How did you hear about us?', self::TD), 'text', 'heard'],
            'message'          => [__('Anything else? (experience, ideas, questions)', self::TD), 'textarea', 'message'],
        ];
    }

    private static function required_always() {
        return ['given', 'family', 'email', 'phone', 'dob'];
    }

    private static function interests() {
        return [
            'portfolio' => __('Portfolio / test shoots', self::TD), 'fashion' => __('Fashion', self::TD),
            'commercial' => __('Commercial & advertising', self::TD), 'beauty' => __('Beauty', self::TD),
            'editorial' => __('Editorial', self::TD), 'lifestyle' => __('Lifestyle', self::TD),
            'fitness' => __('Fitness & sport', self::TD), 'headshots' => __('Headshots', self::TD),
            'cultural' => __('Bridal & cultural wear', self::TD),
        ];
    }

    private static function adult_interests() {
        return ['swimwear' => __('Swimwear', self::TD), 'lingerie' => __('Lingerie', self::TD), 'boudoir' => __('Boudoir', self::TD),
                'implied' => __('Implied nude', self::TD), 'artNude' => __('Art nude', self::TD)];
    }

    private static function availability() {
        return ['weekdays' => __('Weekdays', self::TD), 'weekends' => __('Weekends', self::TD),
                'evenings' => __('Evenings', self::TD), 'shortNotice' => __('Short notice', self::TD)];
    }

    private static function experience() {
        return ['new' => __('New to modelling', self::TD), 'some' => __('Some experience', self::TD), 'professional' => __('Professional', self::TD)];
    }

    private static function terms() {
        return ['tfp' => __('TFP (trade for photos)', self::TD), 'paid' => __('Paid work', self::TD), 'both' => __('Both', self::TD)];
    }

    private static function comfort() {
        return ['0' => __('Clothed only', self::TD), '1' => __('Swimwear / lingerie', self::TD), '2' => __('Implied nude', self::TD),
                '3' => __('Art nude — topless', self::TD), '4' => __('Art nude — full', self::TD)];
    }

    // MARK: Reading the form

    private static function post($name) {
        return isset($_POST['kallos_' . $name]) ? wp_unslash($_POST['kallos_' . $name]) : '';
    }

    /** A number from the form (decimal comma allowed), or 0. */
    private static function number($name) {
        $raw = str_replace(',', '.', trim((string) self::post($name)));
        return is_numeric($raw) ? (float) $raw : 0.0;
    }

    /** Checked keys from a checkbox group, limited to the allowed ones (keys keep their case, e.g. artNude). */
    private static function checked_keys($name, array $allowed) {
        $raw = isset($_POST['kallos_' . $name]) && is_array($_POST['kallos_' . $name]) ? wp_unslash($_POST['kallos_' . $name]) : [];
        $clean = array_map(function ($v) { return preg_replace('/[^A-Za-z]/', '', (string) $v); }, $raw);
        return array_values(array_intersect(array_keys($allowed), $clean));
    }

    public function maybe_handle() {
        if ('POST' !== ($_SERVER['REQUEST_METHOD'] ?? '') || empty($_POST['kallos_model_form'])) {
            return;
        }
        // Spam checks: a hidden field people never fill in, and a minimum time on the page.
        if (!empty($_POST['kallos_website'])) {
            $this->errors['_form'] = __('Sorry, the form could not be sent.', self::TD);
            return;
        }
        $started = sanitize_text_field((string) ($_POST['kallos_started'] ?? ''));
        $parts = explode('.', $started);
        if (count($parts) !== 2 || !hash_equals(wp_hash($parts[0]), $parts[1]) || (time() - (int) $parts[0]) < self::MIN_SECONDS) {
            $this->errors['_form'] = __('Please take a moment to check your details, then send the form again.', self::TD);
        }

        foreach (self::fields() as $name => $field) {
            if ('' !== $field[2] && !$this->shows($field[2])) {
                $this->values[$name] = '';
                continue;
            }
            $raw = self::post($name);
            if ('email' === $field[1]) {
                $value = sanitize_email($raw);
            } elseif ('textarea' === $field[1]) {
                $value = sanitize_textarea_field($raw);
            } elseif ('url' === $field[1]) {
                $value = esc_url_raw(trim($raw));
            } else {
                $value = sanitize_text_field($raw);
            }
            $this->values[$name] = mb_substr($value, 0, 'message' === $name ? 2000 : 200);
        }
        $required = self::required_always();
        if ($this->requires('address')) {
            array_push($required, 'street', 'suburb', 'state', 'postcode', 'country');
        } elseif ($this->requires('suburb')) {
            $required[] = 'suburb';
        }
        foreach ($required as $name) {
            if ('' === $this->values[$name]) {
                /* translators: %s: a field name, e.g. "first name" */
                $this->errors[$name] = sprintf(__('Please fill in %s.', self::TD), mb_strtolower(self::fields()[$name][0]));
            }
        }
        if ('' !== $this->values['email'] && !is_email($this->values['email'])) {
            $this->errors['email'] = __('Please check the email address.', self::TD);
        }
        if ($this->requires('social') && '' === $this->values['instagram'] && '' === $this->values['portfolio']) {
            $this->errors['instagram'] = __('Please add your Instagram or a portfolio link (or both).', self::TD);
        }

        // Age decides what can be asked: under 18 needs a parent or guardian, and never
        // gets comfort levels or adults-only shoot types (they're dropped here too).
        $age = $this->age($this->values['dob']);
        if ('' !== $this->values['dob'] && null === $age) {
            $this->errors['dob'] = __('Please check the date of birth.', self::TD);
        }
        $minor = null !== $age && $age < 18;
        $adult = null !== $age && $age >= 18;
        if ($minor) {
            $needed = [
                'guardian'      => __("Under 18: please add the parent or guardian's name.", self::TD),
                'guardianPhone' => __("Under 18: please add the parent or guardian's mobile.", self::TD),
                'guardianEmail' => __("Under 18: please add the parent or guardian's email.", self::TD),
            ];
            foreach ($needed as $name => $message) {
                if ('' === $this->values[$name]) {
                    $this->errors[$name] = $message;
                }
            }
            if (empty($_POST['kallos_guardian_ok'])) {
                $this->errors['guardian_ok'] = __('Under 18: a parent or guardian needs to agree to this form.', self::TD);
            }
        }

        // Measurements: cm, or inches (height in feet and inches). Kept in cm.
        $unit = 'in' === self::post('unit') ? 'in' : 'cm';
        $this->values['unit'] = $unit;
        foreach (['height', 'bust', 'waist', 'hips'] as $name) {
            $this->values[$name] = 0;
        }
        if ($this->shows('measurements')) {
            if ('in' === $unit) {
                $height = (self::number('height_ft') * 12 + self::number('height_in')) * 2.54;
                $factor = 2.54;
            } else {
                $height = self::number('height');
                $factor = 1;
            }
            $this->values['height'] = $height >= 80 && $height <= 260 ? round($height, 1) : 0;
            $labels = ['bust' => __('bust or chest', self::TD), 'waist' => __('waist', self::TD), 'hips' => __('hips', self::TD)];
            foreach ($labels as $name => $what) {
                $cm = round(self::number($name) * $factor, 1);
                $this->values[$name] = $cm >= 40 && $cm <= 250 ? $cm : 0;
                if ($this->requires('measurements') && 0 == $this->values[$name]) {
                    /* translators: %s: bust or chest, waist or hips */
                    $this->errors[$name] = sprintf(__('Please add your %s measurement.', self::TD), $what);
                }
            }
            if ($this->requires('measurements') && 0 == $this->values['height']) {
                $this->errors['height'] = __('Please add your height.', self::TD);
            }
        }
        foreach (['dress', 'shoe'] as $name) {
            $size = $this->shows('measurements') ? sanitize_text_field(self::post($name)) : '';
            $system = in_array(self::post($name . '_system'), self::SIZE_SYSTEMS, true) ? self::post($name . '_system') : '';
            $this->values[$name . '_raw'] = mb_substr($size, 0, 20);
            $this->values[$name . '_system'] = $system;
            $this->values[$name] = '' === $size ? '' : trim(mb_substr($size, 0, 20) . ' ' . $system);
        }

        $exp = sanitize_key(self::post('experience'));
        $this->values['experience'] = $this->shows('work') && array_key_exists($exp, self::experience()) ? $exp : '';
        $terms = sanitize_key(self::post('terms'));
        $this->values['terms'] = $this->shows('work') && array_key_exists($terms, self::terms()) ? $terms : '';
        if ($this->requires('experience') && '' === $this->values['experience']) {
            $this->errors['experience'] = __('Please choose your experience.', self::TD);
        }
        if ($this->requires('terms') && '' === $this->values['terms']) {
            $this->errors['terms'] = __('Please choose the kind of work (TFP, paid or both).', self::TD);
        }

        $interests = $this->shows('interests') ? self::checked_keys('interests', self::interests()) : [];
        $adultInterests = $adult && $this->shows('adult') ? self::checked_keys('adult_interests', self::adult_interests()) : [];
        $this->values['interests'] = array_merge($interests, $adultInterests);
        if ($this->requires('interests') && !$this->values['interests']) {
            $this->errors['interests'] = __('Please choose at least one kind of shoot.', self::TD);
        }
        $this->values['availability'] = $this->shows('availability') ? self::checked_keys('availability', self::availability()) : [];
        if ($this->requires('availability') && !$this->values['availability']) {
            $this->errors['availability'] = __('Please choose when you are usually available.', self::TD);
        }
        $comfort = (string) (int) self::post('comfort');
        $this->values['comfort'] = $adult && $this->shows('adult') && array_key_exists($comfort, self::comfort()) ? $comfort : '0';
        $this->values['privateOK'] = $adult && $this->shows('adult') && !empty($_POST['kallos_privateOK']);

        if (empty($_POST['kallos_consent'])) {
            $this->errors['consent'] = __('Please agree to your details being sent by email.', self::TD);
        }
        if ($this->errors) {
            return;
        }

        if ($this->send($minor, (int) $age)) {
            // Back to the page the form was on (the referrer can be missing in private browsers).
            $page = isset($_POST['kallos_back']) ? esc_url_raw(wp_unslash($_POST['kallos_back'])) : '';
            $back = wp_validate_redirect($page, '') ?: (wp_get_referer() ?: home_url('/'));
            wp_safe_redirect(add_query_arg('kallos_sent', '1', remove_query_arg('kallos_sent', $back)) . '#kallos-model-form');
            exit;
        }
        $this->errors['_form'] = __('Sorry, the form could not be sent just now. Please try again later or email us directly.', self::TD);
    }

    /** Age in whole years, or null for a date that isn't real or is in the future. */
    private function age($dob) {
        $date = DateTime::createFromFormat('!Y-m-d', $dob, wp_timezone());
        if (!$date || $date->format('Y-m-d') !== $dob) {
            return null;
        }
        $now = new DateTime('now', wp_timezone());
        if ($date > $now || (int) $date->format('Y') < 1900) {
            return null;
        }
        return (int) $date->diff($now)->y;
    }

    private static function length($cm, $unit) {
        if ($cm <= 0) {
            return '';
        }
        return 'in' === $unit ? round($cm / 2.54 * 2) / 2 . ' in (' . round($cm) . ' cm)' : round($cm) . ' cm';
    }

    private static function height($cm, $unit) {
        if ($cm <= 0) {
            return '';
        }
        if ('in' === $unit) {
            $inches = (int) round($cm / 2.54);
            return intdiv($inches, 12) . ' ft ' . ($inches % 12) . ' in (' . round($cm) . ' cm)';
        }
        return round($cm) . ' cm';
    }

    // MARK: The email

    /** The site's own "Add to Kallos One" helper page. */
    private static function helper_url() {
        return add_query_arg('kallos_add_model', '1', home_url('/'));
    }

    private function send($minor, $age) {
        $v = $this->values;
        $settings = $this->settings();
        // Line breaks never reach email headers (WordPress already strips them; this is belt and braces).
        $name = trim(preg_replace('/[\r\n\t]+/', ' ', $v['given'] . ' ' . $v['family']));

        // What goes in the Add to Kallos One link (Kallos One reads these names).
        $query = ['v' => '1'];
        foreach (self::fields() as $field => $unused) {
            if ('' !== $v[$field]) {
                $query[$field] = $v[$field];
            }
        }
        foreach (['height', 'bust', 'waist', 'hips'] as $field) {
            if ($v[$field] > 0) {
                $query[$field] = (string) $v[$field];
            }
        }
        $query['unit'] = $v['unit'];
        foreach (['dress', 'shoe', 'experience', 'terms'] as $field) {
            if ('' !== $v[$field]) {
                $query[$field] = $v[$field];
            }
        }
        if ($v['interests']) {
            $query['interests'] = implode(',', $v['interests']);
        }
        if ($v['availability']) {
            $query['availability'] = implode(',', $v['availability']);
        }
        if ('0' !== $v['comfort']) {
            $query['comfort'] = $v['comfort'];
        }
        if ($v['privateOK']) {
            $query['privateOK'] = '1';
        }
        $query['sent'] = wp_date('Y-m-d');
        // rawurlencode: spaces as %20, "+" kept as %2B (phone numbers). The details go after
        // the # sign, which browsers never send to the website.
        $pairs = [];
        foreach ($query as $key => $value) {
            $pairs[] = rawurlencode($key) . '=' . rawurlencode((string) $value);
        }
        $link = self::helper_url() . '#' . implode('&', $pairs);

        // What the email shows.
        $shown = [];
        foreach (self::fields() as $field => $meta) {
            if ('' === $v[$field]) {
                continue;
            }
            $shown[$meta[0]] = 'dob' === $field
                /* translators: 1: date of birth, 2: age in years */
                ? sprintf(__('%1$s (age %2$d)', self::TD), wp_date(get_option('date_format') ?: 'j F Y', strtotime($v['dob'] . ' 12:00')), $age)
                : $v[$field];
        }
        $shown[__('Height', self::TD)] = self::height($v['height'], $v['unit']);
        $shown[__('Bust / chest', self::TD)] = self::length($v['bust'], $v['unit']);
        $shown[__('Waist', self::TD)] = self::length($v['waist'], $v['unit']);
        $shown[__('Hips', self::TD)] = self::length($v['hips'], $v['unit']);
        $shown[__('Dress / suit size', self::TD)] = $v['dress'];
        $shown[__('Shoe size', self::TD)] = $v['shoe'];
        $shown[__('Experience', self::TD)] = $v['experience'] ? self::experience()[$v['experience']] : '';
        $shown[__('Work', self::TD)] = $v['terms'] ? self::terms()[$v['terms']] : '';
        $all = self::interests() + self::adult_interests();
        $shown[__('Interested in', self::TD)] = implode(', ', array_map(function ($k) use ($all) { return $all[$k]; }, $v['interests']));
        $avail = self::availability();
        $shown[__('Available', self::TD)] = implode(', ', array_map(function ($k) use ($avail) { return $avail[$k]; }, $v['availability']));
        if ('0' !== $v['comfort'] || $v['privateOK']) {
            $shown[__('Comfort level', self::TD)] = self::comfort()[$v['comfort']] . ($v['privateOK'] ? ' · ' . __('OK with private images', self::TD) : '');
        }

        $rows = '';
        $text = '';
        foreach ($shown as $label => $value) {
            if ('' === (string) $value) {
                continue;
            }
            $rows .= '<tr><td style="padding:6px 12px 6px 0;color:#6b655d;vertical-align:top;white-space:nowrap">' . esc_html($label)
                . '</td><td style="padding:6px 0;vertical-align:top">' . nl2br(esc_html($value)) . '</td></tr>';
            $text .= $label . ': ' . $value . "\n";
        }
        $under18 = __('Under 18. A parent or guardian must sign every release and be present. Adults-only shoots are never allowed.', self::TD);
        $warning = $minor ? '<p style="background:#fde8e8;color:#9b1c1c;padding:10px 12px;border-radius:8px"><strong>' . esc_html($under18) . '</strong></p>' : '';
        $colour = self::colour($settings['button_colour']);
        $buttonText = self::text_on($colour);
        /* translators: %s: the model's name */
        $title = sprintf(__('New model: %s', self::TD), $name);

        $html = '<div style="font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:15px;color:#1d1b18;max-width:560px">'
            . '<h2 style="margin:0 0 4px">' . esc_html($title) . '</h2>'
            /* translators: %s: the studio name */
            . '<p style="color:#6b655d;margin:0 0 16px">' . esc_html(sprintf(__('Sent from the model form on %s.', self::TD), $settings['studio'])) . '</p>'
            . $warning
            . '<p><a href="' . esc_url($link) . '" style="display:inline-block;background:' . esc_attr($colour) . ';color:' . esc_attr($buttonText) . ';text-decoration:none;font-weight:600;padding:12px 20px;border-radius:10px">' . esc_html__('Add to Kallos One', self::TD) . '</a></p>'
            . '<p style="color:#6b655d;font-size:13px">' . esc_html__('Open this email on your iPhone, iPad or Mac with Kallos One installed, then tap the button. You check everything before it\'s saved.', self::TD) . '</p>'
            . '<table style="border-collapse:collapse;margin-top:12px">' . $rows . '</table>'
            . '</div>';
        $plain = $title . "\n\n" . ($minor ? $under18 . "\n\n" : '')
            . __('Add to Kallos One:', self::TD) . "\n" . $link . "\n\n" . $text;

        $headers = ['Content-Type: text/html; charset=UTF-8'];
        if (is_email($v['email'])) {
            // Only plain name characters in the header's display name.
            $display = trim(preg_replace('/[^\p{L}\p{N} .\'-]+/u', '', $name));
            $headers[] = 'Reply-To: ' . ('' === $display ? '' : $display . ' ') . '<' . $v['email'] . '>';
        }
        // A plain-text copy for email apps that don't show HTML.
        $alt = function ($mailer) use ($plain) { $mailer->AltBody = $plain; };
        add_action('phpmailer_init', $alt);
        $sent = wp_mail($settings['to'], $title, $html, $headers);
        remove_action('phpmailer_init', $alt);
        return $sent;
    }

    private static function colour($value) {
        $c = sanitize_hex_color((string) $value);
        return $c ?: '#111111';
    }

    /** Black or white text, whichever reads better on the colour. */
    private static function text_on($hex) {
        $hex = ltrim($hex, '#');
        if (3 === strlen($hex)) {
            $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
        }
        $r = hexdec(substr($hex, 0, 2)); $g = hexdec(substr($hex, 2, 2)); $b = hexdec(substr($hex, 4, 2));
        return (0.299 * $r + 0.587 * $g + 0.114 * $b) > 160 ? '#111111' : '#ffffff';
    }

    // MARK: The helper page

    /** /?kallos_add_model=1#… opens Kallos One with the details after the # (never sent here). */
    public function maybe_helper_page() {
        if (empty($_GET['kallos_add_model'])) {
            return;
        }
        nocache_headers();
        header('Content-Type: text/html; charset=utf-8');
        header('X-Robots-Tag: noindex, nofollow');
        header('Referrer-Policy: no-referrer');
        $title = esc_html__('Add to Kallos One', self::TD);
        $intro = esc_html__('Opening Kallos One with this model\'s details, ready for you to check and save.', self::TD);
        $none = esc_js(__('This link doesn\'t carry any details. Open it from the email your model form sent you.', self::TD));
        $open = esc_html__('Open in Kallos One', self::TD);
        $note1 = esc_html__('Nothing is saved until you tap Save Model in Kallos One. This page doesn\'t send or keep any details: they stay in your email and on your device.', self::TD);
        $note2 = esc_html__('Kallos One needs to be installed on this iPhone, iPad or Mac.', self::TD);
        $colour = esc_attr(self::colour($this->settings()['button_colour']));
        $textColour = esc_attr(self::text_on(self::colour($this->settings()['button_colour'])));
        echo '<!doctype html><html lang="' . esc_attr(get_bloginfo('language')) . '"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex, nofollow"><meta name="referrer" content="no-referrer"><title>' . $title . '</title>'
            . '<style>:root{--bg:#f6f3ee;--card:#fff;--ink:#1d1b18;--muted:#6b655d}@media(prefers-color-scheme:dark){:root{--bg:#141210;--card:#1f1c19;--ink:#f2ede6;--muted:#a39b90}}*{box-sizing:border-box}body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px 16px;background:var(--bg);color:var(--ink);font:16px/1.5 -apple-system,BlinkMacSystemFont,"Helvetica Neue",Arial,sans-serif}main{width:100%;max-width:440px;background:var(--card);border-radius:20px;padding:28px 24px;box-shadow:0 10px 30px rgba(0,0,0,.08)}h1{font-size:22px;margin:0 0 6px}p{margin:0 0 14px;color:var(--muted)}.who{font-size:18px;color:var(--ink);font-weight:600;margin:16px 0}a.b{display:block;text-align:center;text-decoration:none;background:' . $colour . ';color:' . $textColour . ';font-weight:600;padding:14px 18px;border-radius:14px;margin:18px 0 12px}.s{font-size:13px}</style></head>'
            . '<body><main><h1>' . $title . '</h1><p id="intro">' . $intro . '</p><div class="who" id="who"></div><a class="b" id="open" href="#">' . $open . '</a><p class="s">' . $note1 . '</p><p class="s">' . $note2 . '</p></main>'
            . '<script>(function(){var q=(location.hash||"").replace(/^#/,""),o=document.getElementById("open"),w=document.getElementById("who");'
            . 'if(!q){document.getElementById("intro").textContent="' . $none . '";o.style.display="none";return;}'
            . 'try{var p=new URLSearchParams(q),n=[p.get("given"),p.get("family")].filter(Boolean).join(" ");if(n)w.textContent=n;}catch(e){}'
            . 'var t="kallosone://add-model?"+q;o.href=t;setTimeout(function(){window.location.href=t;},300);})();</script></body></html>';
        exit;
    }

    // MARK: The form

    public function shortcode() {
        $settings = $this->settings();
        $colour = self::colour($settings['button_colour']);
        $textColour = self::text_on($colour);
        ob_start();
        echo '<div class="kallos-mf" id="kallos-model-form">';
        echo '<style>
            .kallos-mf{max-width:640px}
            .kallos-mf .row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
            .kallos-mf .row3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px}
            @media(max-width:560px){.kallos-mf .row,.kallos-mf .row3{grid-template-columns:1fr}}
            .kallos-mf label{display:block;font-size:14px;margin:10px 0 4px}
            .kallos-mf input[type=text],.kallos-mf input[type=email],.kallos-mf input[type=tel],.kallos-mf input[type=url],.kallos-mf input[type=date],.kallos-mf select,.kallos-mf textarea{width:100%;padding:10px;border:1px solid #ccc;border-radius:8px;font-size:16px;box-sizing:border-box;background:#fff}
            .kallos-mf .err{color:#b42318 !important;font-size:13px;margin-top:2px}
            .kallos-mf .box{background:#f6f3ee;border-radius:10px;padding:12px 14px;margin:14px 0}
            .kallos-mf .check{display:flex;gap:8px;align-items:flex-start;font-size:14px;margin:8px 0}
            .kallos-mf .check input{margin-top:4px}
            .kallos-mf .choices{display:grid;grid-template-columns:1fr 1fr;gap:2px 12px}
            @media(max-width:560px){.kallos-mf .choices{grid-template-columns:1fr}}
            .kallos-mf .hp{position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden}
            .kallos-mf .ok{background:#e8f5ec;color:#1e5b33;border-radius:10px;padding:14px}
            .kallos-mf h3{margin:24px 0 4px}
            .kallos-mf .kallos-title{margin:0 0 6px}
            .kallos-mf .kallos-intro{font-size:15px;color:#4a453f;margin:0 0 14px}
            .kallos-mf .kallos-addr{position:relative}
            .kallos-mf .kallos-sugg{position:absolute;left:0;right:0;top:100%;z-index:50;background:#fff;border:1px solid #bbb;border-radius:8px;box-shadow:0 6px 18px rgba(0,0,0,.12);margin-top:2px;overflow:hidden}
            .kallos-mf .kallos-sugg button{display:block;width:100%;text-align:left;background:#fff !important;color:#111 !important;border:0 !important;border-bottom:1px solid #eee !important;padding:10px 12px !important;font-size:15px !important;font-weight:400 !important;cursor:pointer;border-radius:0 !important}
            .kallos-mf .kallos-sugg button:hover,.kallos-mf .kallos-sugg button.on{background:#f3efe8 !important}
            .kallos-mf .kallos-sugg .osm{font-size:11px;color:#777;padding:4px 12px}
            .kallos-mf .kallos-wait{font-size:13px;color:#6b655d;margin-top:6px}
            .kallos-mf .hint{font-size:13px;color:#6b655d}
            .kallos-mf .badge{display:inline-block;background:#b42318;color:#fff;border-radius:6px;font-size:11px;font-weight:700;padding:1px 6px;margin-left:6px}
            /* Themes and page builders restyle form controls; these win over them. */
            #kallos-model-form input[type=checkbox],#kallos-model-form input[type=radio]{-webkit-appearance:auto !important;appearance:auto !important;width:18px !important;height:18px !important;min-width:18px;margin:2px 0 0 0 !important;opacity:1 !important;accent-color:' . esc_attr($colour) . ' !important;position:relative !important;display:inline-block !important;border:0 !important;box-shadow:none !important}
            #kallos-model-form input[type=checkbox]::before,#kallos-model-form input[type=checkbox]::after,#kallos-model-form input[type=radio]::before,#kallos-model-form input[type=radio]::after{content:none !important;display:none !important}
            #kallos-model-form label,#kallos-model-form .check{color:#222 !important}
            #kallos-model-form input[type=text],#kallos-model-form input[type=email],#kallos-model-form input[type=tel],#kallos-model-form input[type=url],#kallos-model-form input[type=date],#kallos-model-form select,#kallos-model-form textarea{color:#111 !important;border:1px solid #bbb !important;background:#fff !important}
            #kallos-model-form input[type=date]:invalid:not(:focus),#kallos-model-form input[type=date]:invalid:not(:focus)::-webkit-datetime-edit{color:transparent !important}
            #kallos-model-form button[type=submit]{background:' . esc_attr($colour) . ' !important;color:' . esc_attr($textColour) . ' !important;border:0 !important;border-radius:10px !important;padding:14px 26px !important;font-size:16px !important;font-weight:600 !important;opacity:1 !important;cursor:pointer !important;text-transform:none !important;letter-spacing:normal !important;box-shadow:none !important}
            #kallos-model-form button[type=submit]:hover{filter:brightness(1.15)}
            #kallos-model-form button[type=submit]:disabled{opacity:.45 !important;cursor:not-allowed !important;filter:none}
        </style>';

        echo '<h2 class="kallos-title">' . esc_html($settings['heading']) . '</h2>';
        echo '<p class="kallos-intro">' . esc_html($settings['intro']) . '</p>';

        if (isset($_GET['kallos_sent']) && !$this->errors) {
            echo '<p class="ok">' . esc_html($settings['thanks']) . '</p></div>';
            return ob_get_clean();
        }
        if (!empty($this->errors['_form'])) {
            echo '<p class="err">' . esc_html($this->errors['_form']) . '</p>';
        } elseif ($this->errors) {
            echo '<p class="err">' . esc_html__('Please check the fields marked in red.', self::TD) . '</p>';
        }

        $now = (string) time();
        $unit = $this->values['unit'] ?? ('in' === $settings['unit'] ? 'in' : 'cm');
        echo '<form method="post" action="#kallos-model-form" novalidate>';
        echo '<input type="hidden" name="kallos_model_form" value="1">';
        $here = (is_ssl() ? 'https://' : 'http://') . sanitize_text_field(wp_unslash($_SERVER['HTTP_HOST'] ?? '')) . esc_url_raw(wp_unslash($_SERVER['REQUEST_URI'] ?? '/'));
        echo '<input type="hidden" name="kallos_back" value="' . esc_attr(remove_query_arg('kallos_sent', $here)) . '">';
        echo '<input type="hidden" name="kallos_started" value="' . esc_attr($now . '.' . wp_hash($now)) . '">';
        echo '<div class="hp" aria-hidden="true"><label>Website<input type="text" name="kallos_website" tabindex="-1" autocomplete="off"></label></div>';
        echo '<p class="hint">' . esc_html__('Fields marked * are needed.', self::TD) . '</p>';

        echo '<h3>' . esc_html__('About you', self::TD) . '</h3>';
        echo '<div class="row">' . $this->input('given', 'given-name', true) . $this->input('family', 'family-name', true) . '</div>';
        echo '<div class="row">' . $this->input('middle', 'additional-name') . $this->input('nickname', 'nickname') . '</div>';
        echo '<div class="row">' . $this->input('email', 'email', true) . $this->input('phone', 'tel', true) . '</div>';
        echo '<div class="row">' . $this->input('dob', 'bday', true) . '<div></div></div>';

        echo '<div class="box" id="kallos-guardian"><strong>' . esc_html__('Under 18?', self::TD) . '</strong> ' . esc_html__('A parent or guardian needs to fill in their details and agree below. Shoots for anyone under 18 are always with a parent or guardian present.', self::TD);
        echo '<div class="row">' . $this->input('guardian', 'off', true) . $this->input('guardianRelation', 'off') . '</div>';
        echo '<div class="row">' . $this->input('guardianPhone', 'off', true) . $this->input('guardianEmail', 'off', true) . '</div>';
        echo '<label class="check"><input type="checkbox" name="kallos_guardian_ok" value="1" required' . checked(!empty($_POST['kallos_guardian_ok']), true, false) . '> ' . esc_html__('I am the parent or guardian and I agree to these details being sent.', self::TD) . '</label>';
        echo $this->error('guardian_ok');
        echo '</div>';

        if ($this->shows('address')) {
            $all = $this->requires('address');
            echo '<h3>' . esc_html__('Where you live', self::TD) . '</h3>';
            echo '<div class="kallos-addr">' . $this->input('street', 'street-address', $all) . '</div>';
            if (!empty($settings['address_search'])) {
                echo '<p class="hint">' . esc_html('' !== $settings['mapkit_token']
                    ? __('Start typing your street address and choose it from the list to fill in the rest. Suggestions come from Apple Maps: what you type in this box is sent to Apple\'s address search.', self::TD)
                    : __('Start typing your street address and choose it from the list to fill in the rest. Suggestions come from OpenStreetMap: what you type in this box is sent to its address search.', self::TD)) . '</p>';
            }
            echo '<div class="row">' . $this->input('suburb', 'address-level2', $all || $this->requires('suburb')) . $this->input('state', 'address-level1', $all) . '</div>';
            echo '<div class="row">' . $this->input('postcode', 'postal-code', $all) . $this->input('country', 'country-name', $all) . '</div>';
        }

        if ($this->shows('measurements')) {
            $req = $this->requires('measurements') ? ' *' : '';
            echo '<h3>' . esc_html__('Measurements', self::TD) . '</h3>';
            echo '<div class="check">' . esc_html__('Units:', self::TD) . ' <label class="check" style="margin:0"><input type="radio" name="kallos_unit" value="cm"' . checked('cm', $unit, false) . '> cm</label>'
                . '<label class="check" style="margin:0"><input type="radio" name="kallos_unit" value="in"' . checked('in', $unit, false) . '> ' . esc_html__('inches', self::TD) . '</label></div>';
            $m = $this->requires('measurements');
            echo '<div class="kallos-cm"><div class="row">' . $this->number_field('height', __('Height (cm)', self::TD) . $req, '', $m) . '<div></div></div></div>';
            echo '<div class="kallos-in"><div class="row">' . $this->number_field('height_ft', __('Height: feet', self::TD) . $req, '', $m) . $this->number_field('height_in', __('and inches', self::TD), '') . '</div></div>';
            echo $this->error('height');
            echo '<div class="row3">' . $this->number_field('bust', __('Bust / chest', self::TD) . $req, '', $m) . $this->number_field('waist', __('Waist', self::TD) . $req, '', $m) . $this->number_field('hips', __('Hips', self::TD) . $req, '', $m) . '</div>';
            echo '<p class="hint kallos-unit-hint" data-cm="' . esc_attr__('In cm.', self::TD) . '" data-in="' . esc_attr__('In inches.', self::TD) . '">' . esc_html('in' === $unit ? __('In inches.', self::TD) : __('In cm.', self::TD)) . '</p>';
            echo '<div class="row">' . $this->size('dress', __('Dress / suit size', self::TD)) . $this->size('shoe', __('Shoe size', self::TD)) . '</div>';
        }

        if ($this->shows('look')) {
            echo '<h3>' . esc_html__('Your look', self::TD) . '</h3>';
            echo '<div class="row">' . $this->input('hair', 'off') . $this->input('eyes', 'off') . '</div>';
            echo '<div class="row">' . $this->input('tattoos', 'off') . $this->input('piercings', 'off') . '</div>';
        }

        if ($this->shows('work') || $this->shows('interests') || $this->shows('availability')) {
            echo '<h3>' . esc_html__('Your work', self::TD) . '</h3>';
        }
        if ($this->shows('work')) {
            if ($this->requires('social')) {
                echo '<p class="hint" style="margin-top:10px"><strong>' . esc_html__('Instagram or a portfolio link is needed (or both).', self::TD) . ' *</strong></p>';
            }
            echo '<div class="row"' . ($this->requires('social') ? ' data-kallos-oneof="1"' : '') . '>' . $this->input('instagram', 'off') . $this->input('portfolio', 'url') . '</div>';
            echo $this->input('agency', 'organization');
            echo '<label>' . esc_html__('Experience', self::TD) . ($this->requires('experience') ? ' *' : '') . '</label>' . $this->radios('experience', self::experience(), $this->requires('experience'));
            echo $this->error('experience');
            echo '<label>' . esc_html__('Kind of work', self::TD) . ($this->requires('terms') ? ' *' : '') . '</label>' . $this->radios('terms', self::terms(), $this->requires('terms'));
            echo $this->error('terms');
        }
        if ($this->shows('interests')) {
            echo '<div' . ($this->requires('interests') ? ' data-kallos-group="interests"' : '') . '><label>' . esc_html__('Kinds of shoots you\'re interested in', self::TD) . ($this->requires('interests') ? ' *' : '') . '</label>' . $this->checks('interests', self::interests());
            echo $this->error('interests');
        }
        if ($this->shows('adult')) {
            echo '<div class="box kallos-adult"><strong>' . esc_html__('18 and over only', self::TD) . '</strong> <span class="badge">18+</span><div class="hint">' . esc_html__('Shown only when your date of birth shows you are 18 or older.', self::TD) . '</div>';
            echo $this->checks('adult_interests', self::adult_interests());
            echo '<label for="kallos_comfort">' . esc_html__('How far are you comfortable going?', self::TD) . '</label><select name="kallos_comfort" id="kallos_comfort">';
            foreach (self::comfort() as $key => $label) {
                echo '<option value="' . esc_attr($key) . '"' . selected((string) $key, (string) ($this->values['comfort'] ?? '0'), false) . '>' . esc_html($label) . '</option>';
            }
            echo '</select>';
            echo '<label class="check"><input type="checkbox" name="kallos_privateOK" value="1"' . checked(!empty($this->values['privateOK']), true, false) . '> ' . esc_html__('I\'m OK with private images (kept off portfolios and social media)', self::TD) . '</label>';
            echo '<div class="hint">' . esc_html__('For the photographer\'s records only. Every shoot still has its own signed release, and you can always say no.', self::TD) . '</div>';
            echo '</div>';
        }
        if ($this->shows('interests')) {
            echo '</div>'; // Adults-only shoot types count towards "at least one kind of shoot".
        }
        if ($this->shows('availability')) {
            echo '<div' . ($this->requires('availability') ? ' data-kallos-group="availability"' : '') . '><label>' . esc_html__('When are you usually available?', self::TD) . ($this->requires('availability') ? ' *' : '') . '</label>' . $this->checks('availability', self::availability()) . '</div>';
            echo $this->error('availability');
        }
        if ($this->shows('travel')) {
            echo $this->input('travel', 'off');
        }
        if ($this->shows('heard')) {
            echo $this->input('heard', 'off');
        }
        if ($this->shows('message')) {
            echo $this->input('message', 'off');
        }

        $consent = esc_html($settings['consent']);
        if ('' !== $settings['privacy_url']) {
            $consent .= ' <a href="' . esc_url($settings['privacy_url']) . '" target="_blank" rel="noopener">' . esc_html__('Privacy policy', self::TD) . '</a>';
        }
        echo '<label class="check"><input type="checkbox" name="kallos_consent" value="1" required' . checked(!empty($_POST['kallos_consent']), true, false) . '> <span>' . $consent . '</span></label>';
        echo $this->error('consent');
        if ($this->errors) {
            echo '<p class="err">' . esc_html(!empty($this->errors['_form']) ? $this->errors['_form'] : __('Something is missing: please check the fields marked in red above.', self::TD)) . '</p>';
        }
        echo '<p><button type="submit" id="kallos-send">' . esc_html($settings['button']) . '</button></p>';
        echo '<p class="kallos-wait" id="kallos-wait" style="display:none">' . esc_html__('Fill in everything marked * to send.', self::TD) . '</p>';
        echo '</form>';
        // Under 18: show the parent box, hide the 18+ box. Units: cm or feet and inches.
        echo '<script>(function(){var f=document.getElementById("kallos-model-form");if(!f)return;'
            . 'var d=f.querySelector("input[name=kallos_dob]"),g=document.getElementById("kallos-guardian"),a=f.querySelector(".kallos-adult");'
            . 'function age(){var v=d&&d.value;if(!v)return null;var t=new Date(),x=new Date(v+"T12:00:00");var n=t.getFullYear()-x.getFullYear();if(t.getMonth()<x.getMonth()||(t.getMonth()===x.getMonth()&&t.getDate()<x.getDate()))n--;return n;}'
            . 'function u(){var n=age();if(g)g.style.display=(n===null||n<18)?"":"none";if(a){var show=n!==null&&n>=18;a.style.display=show?"":"none";if(!show){a.querySelectorAll("input[type=checkbox]").forEach(function(c){c.checked=false;});var s=a.querySelector("select");if(s)s.value="0";}}}'
            . 'function units(){var r=f.querySelector("input[name=kallos_unit]:checked"),inch=r&&r.value==="in";f.querySelectorAll(".kallos-cm").forEach(function(e){e.style.display=inch?"none":"";});f.querySelectorAll(".kallos-in").forEach(function(e){e.style.display=inch?"":"none";});var h=f.querySelector(".kallos-unit-hint");if(h)h.textContent=inch?h.getAttribute("data-in"):h.getAttribute("data-cm");}'
            . 'if(d)d.addEventListener("change",u);f.querySelectorAll("input[name=kallos_unit]").forEach(function(r){r.addEventListener("change",units);});u();units();'
            // 2.1.0: the button works only when everything needed is filled in (the server checks again).
            . 'var b=document.getElementById("kallos-send"),w=document.getElementById("kallos-wait"),em=/^[^ @]+@[^ @]+[.][^ @]+$/;'
            . 'function vis(e){return !!(e.offsetWidth||e.offsetHeight||e.getClientRects().length);}'
            . 'function ok(){var good=true;f.querySelectorAll("input[required],select[required],textarea[required]").forEach(function(e){if(!vis(e))return;if(e.type==="checkbox"){if(!e.checked)good=false;}else if(!e.value.trim()){good=false;}else if(e.type==="email"&&!em.test(e.value.trim())){good=false;}});'
            . 'f.querySelectorAll("[data-kallos-group]").forEach(function(g){if(!vis(g))return;var c=false;g.querySelectorAll("input").forEach(function(i){if(i.checked&&vis(i))c=true;});if(!c)good=false;});'
            . 'f.querySelectorAll("[data-kallos-oneof]").forEach(function(g){var c=false;g.querySelectorAll("input").forEach(function(i){if(i.value.trim())c=true;});if(!c)good=false;});return good;}'
            . 'function check(){if(!b)return;var g=ok();b.disabled=!g;if(w)w.style.display=g?"none":"";}'
            . 'f.addEventListener("input",check);f.addEventListener("change",function(){setTimeout(check,0);});check();'
            . '})();</script>';
        if ($this->shows('address') && !empty($settings['address_search'])) {
            echo '' !== $settings['mapkit_token'] ? $this->apple_address_script($settings) : $this->address_script($settings['country']);
        }
        echo '</div>';
        return ob_get_clean();
    }

    /** Two-letter code for the country set in Settings, to keep Apple Maps suggestions there. */
    private static function country_code($country) {
        $codes = ['australia' => 'au', 'new zealand' => 'nz', 'pakistan' => 'pk', 'india' => 'in', 'united kingdom' => 'gb', 'uk' => 'gb',
                  'england' => 'gb', 'united states' => 'us', 'usa' => 'us', 'canada' => 'ca', 'united arab emirates' => 'ae', 'uae' => 'ae',
                  'ireland' => 'ie', 'singapore' => 'sg', 'malaysia' => 'my', 'south africa' => 'za', 'germany' => 'de', 'france' => 'fr',
                  'italy' => 'it', 'spain' => 'es', 'netherlands' => 'nl', 'japan' => 'jp', 'bangladesh' => 'bd', 'sri lanka' => 'lk',
                  'saudi arabia' => 'sa', 'qatar' => 'qa', 'philippines' => 'ph', 'indonesia' => 'id', 'fiji' => 'fj'];
        return $codes[strtolower(trim((string) $country))] ?? '';
    }

    /** 2.2.0: address suggestions from Apple Maps (MapKit JS), the same addresses as the app. */
    private function apple_address_script(array $settings) {
        $token = wp_json_encode((string) $settings['mapkit_token']);
        $code = wp_json_encode(self::country_code($settings['country']));
        $credit = wp_json_encode(__('Address search by Apple Maps', self::TD));
        return '<script>(function(){var f=document.getElementById("kallos-model-form");if(!f)return;'
            . 'var st=f.querySelector("#kallos_street");if(!st)return;var token=' . $token . ',code=' . $code . ',credit=' . $credit . ';'
            . 'var box=document.createElement("div");box.className="kallos-sugg";box.style.display="none";st.parentNode.appendChild(box);'
            . 'var search=null,timer=null,items=[],pick=-1,seq=0;'
            . 'function ready(){if(search)return true;if(!window.mapkit||!mapkit.Search)return false;try{search=new mapkit.Search({language:"en",includePointsOfInterest:false,includeQueries:false,includeAddresses:true});}catch(e){return false;}return true;}'
            . 'window.kallosMapKitReady=function(){try{mapkit.init({authorizationCallback:function(done){done(token);},language:"en"});}catch(e){}ready();};'
            . 'var sc=document.createElement("script");sc.src="https://cdn.apple-mapkit.com/mk/5.x.x/mapkit.core.js";sc.crossOrigin="anonymous";sc.async=true;'
            . 'sc.setAttribute("data-callback","kallosMapKitReady");sc.setAttribute("data-libraries","services");document.head.appendChild(sc);'
            . 'function set(n,v){var e=f.querySelector("#kallos_"+n);if(e&&v){e.value=v;}}'
            . 'function close(){box.style.display="none";box.innerHTML="";items=[];pick=-1;}'
            . 'function street(p){return p.fullThoroughfare||[p.subThoroughfare,p.thoroughfare].filter(Boolean).join(" ")||p.name||"";}'
            . 'function fill(p){set("street",street(p));set("suburb",p.locality||p.subLocality||"");set("state",p.administrativeArea);set("postcode",p.postCode);set("country",p.country);}'
            . 'function use(r){fill(r);close();f.dispatchEvent(new Event("input"));'
            . 'try{search.search(r,function(err,d){var p=!err&&d&&d.places&&d.places[0];if(p){fill(p);f.dispatchEvent(new Event("input"));}},{language:"en"});}catch(e){}}'
            . 'function show(list){box.innerHTML="";items=list;pick=-1;if(!list.length){close();return;}'
            . 'list.forEach(function(r){var o=document.createElement("button");o.type="button";o.textContent=(r.displayLines||[]).join(", ");o.addEventListener("mousedown",function(e){e.preventDefault();use(r);});o.addEventListener("touchend",function(e){e.preventDefault();use(r);});box.appendChild(o);});'
            . 'var a=document.createElement("div");a.className="osm";a.textContent=credit;box.appendChild(a);box.style.display="";}'
            . 'function look(){var q=st.value.trim();if(q.length<4||!ready()){close();return;}var mine=++seq;var o={language:"en",includePointsOfInterest:false,includeQueries:false,includeAddresses:true};if(code)o.limitToCountries=code;'
            . 'try{search.autocomplete(q,function(err,d){if(err||mine!==seq)return;show(((d&&d.results)||[]).filter(function(r){return r.thoroughfare||r.fullThoroughfare||(r.displayLines&&r.displayLines.length);}).slice(0,5));},o);}catch(e){}}'
            . 'st.addEventListener("input",function(){clearTimeout(timer);timer=setTimeout(look,300);});'
            . 'st.addEventListener("keydown",function(e){var bs=box.querySelectorAll("button");if(!bs.length)return;'
            . 'if(e.key==="ArrowDown"||e.key==="ArrowUp"){e.preventDefault();pick=(pick+(e.key==="ArrowDown"?1:-1)+bs.length)%bs.length;bs.forEach(function(x,i){x.className=i===pick?"on":"";});}'
            . 'else if(e.key==="Enter"&&pick>=0){e.preventDefault();use(items[pick]);}else if(e.key==="Escape"){close();}});'
            . 'st.addEventListener("blur",function(){setTimeout(close,200);});'
            . '})();</script>';
    }

    /** 2.1.0: address suggestions from OpenStreetMap (Photon) while typing the street. */
    private function address_script($country) {
        $c = wp_json_encode((string) $country);
        $osm = wp_json_encode(__('Address search © OpenStreetMap contributors', self::TD));
        return '<script>(function(){var f=document.getElementById("kallos-model-form");if(!f||!window.fetch)return;'
            . 'var st=f.querySelector("#kallos_street");if(!st)return;var home=' . $c . '.toLowerCase(),osm=' . $osm . ';'
            . 'var box=document.createElement("div");box.className="kallos-sugg";box.style.display="none";st.parentNode.appendChild(box);'
            . 'var timer=null,ctl=null,items=[],pick=-1;'
            . 'function set(n,v){var e=f.querySelector("#kallos_"+n);if(e&&v){e.value=v;}}'
            . 'function close(){box.style.display="none";box.innerHTML="";items=[];pick=-1;}'
            . 'function line(p){var s=[p.housenumber,p.street].filter(Boolean).join(" ");if(!s)s=p.name||"";return s;}'
            . 'function sub(p){return p.locality||p.district||p.city||p.county||"";}'
            . 'function label(p){return [line(p),sub(p),p.state,p.postcode,p.country].filter(Boolean).join(", ");}'
            . 'function use(p){set("street",line(p));set("suburb",sub(p));set("state",p.state);set("postcode",p.postcode);set("country",p.country);close();f.dispatchEvent(new Event("input"));}'
            . 'function show(list){box.innerHTML="";items=list;pick=-1;if(!list.length){close();return;}'
            . 'list.forEach(function(p){var o=document.createElement("button");o.type="button";o.textContent=label(p);o.addEventListener("mousedown",function(e){e.preventDefault();use(p);});o.addEventListener("touchend",function(e){e.preventDefault();use(p);});box.appendChild(o);});'
            . 'var a=document.createElement("div");a.className="osm";a.textContent=osm;box.appendChild(a);box.style.display="";}'
            . 'function look(){var q=st.value.trim();if(q.length<4){close();return;}if(ctl)ctl.abort();ctl=window.AbortController?new AbortController():null;'
            . 'var url="https://photon.komoot.io/api/?limit=8&lang=en&q="+encodeURIComponent(q+(home?" "+home:""));'
            . 'fetch(url,ctl?{signal:ctl.signal}:{}).then(function(r){return r.json();}).then(function(j){'
            . 'var list=(j.features||[]).map(function(x){return x.properties||{};}).filter(function(p){return p.street||p.name;});'
            . 'if(home){var mine=list.filter(function(p){return (p.country||"").toLowerCase()===home;});if(mine.length)list=mine;}'
            . 'show(list.slice(0,5));}).catch(function(){});}'
            . 'st.addEventListener("input",function(){clearTimeout(timer);timer=setTimeout(look,350);});'
            . 'st.addEventListener("keydown",function(e){var bs=box.querySelectorAll("button");if(!bs.length)return;'
            . 'if(e.key==="ArrowDown"||e.key==="ArrowUp"){e.preventDefault();pick=(pick+(e.key==="ArrowDown"?1:-1)+bs.length)%bs.length;bs.forEach(function(x,i){x.className=i===pick?"on":"";});}'
            . 'else if(e.key==="Enter"&&pick>=0){e.preventDefault();use(items[pick]);}else if(e.key==="Escape"){close();}});'
            . 'st.addEventListener("blur",function(){setTimeout(close,200);});'
            . '})();</script>';
    }

    private function error($name) {
        return !empty($this->errors[$name]) ? '<div class="err">' . esc_html($this->errors[$name]) . '</div>' : '';
    }

    private function input($name, $autocomplete, $required = false) {
        $field = self::fields()[$name];
        $label = esc_html($field[0]) . ($required ? ' <span aria-hidden="true">*</span>' : '');
        $default = 'country' === $name ? $this->settings()['country'] : '';
        $value = $this->values[$name] ?? $default;
        $attrs = 'name="kallos_' . esc_attr($name) . '" id="kallos_' . esc_attr($name) . '" autocomplete="' . esc_attr($autocomplete) . '"' . ($required ? ' required' : '');
        if ('textarea' === $field[1]) {
            $control = '<textarea ' . $attrs . ' rows="4" maxlength="2000">' . esc_textarea($value) . '</textarea>';
        } else {
            $max = 'date' === $field[1] ? ' max="' . esc_attr(wp_date('Y-m-d')) . '"' : ' maxlength="200"';
            $control = '<input type="' . esc_attr($field[1]) . '" ' . $attrs . $max . ' value="' . esc_attr($value) . '">';
        }
        return '<div><label for="kallos_' . esc_attr($name) . '">' . $label . '</label>' . $control . $this->error($name) . '</div>';
    }

    private function number_field($name, $label, $placeholder, $required = false) {
        $value = isset($_POST['kallos_' . $name]) ? sanitize_text_field(wp_unslash($_POST['kallos_' . $name])) : '';
        return '<div><label for="kallos_' . esc_attr($name) . '">' . esc_html($label) . '</label>'
            . '<input type="text" inputmode="decimal" name="kallos_' . esc_attr($name) . '" id="kallos_' . esc_attr($name) . '" maxlength="6" placeholder="' . esc_attr($placeholder) . '" value="' . esc_attr($value) . '"' . ($required ? ' required' : '') . '>'
            . (in_array($name, ['height', 'height_ft', 'height_in'], true) ? '' : $this->error($name)) . '</div>';
    }

    private function size($name, $label) {
        $value = $this->values[$name . '_raw'] ?? '';
        $system = $this->values[$name . '_system'] ?? $this->settings()['size_system'];
        $options = '';
        foreach (self::SIZE_SYSTEMS as $s) {
            $options .= '<option value="' . esc_attr($s) . '"' . selected($s, $system, false) . '>' . esc_html($s) . '</option>';
        }
        return '<div><label for="kallos_' . esc_attr($name) . '">' . esc_html($label) . '</label>'
            . '<div style="display:grid;grid-template-columns:2fr 1fr;gap:8px"><input type="text" name="kallos_' . esc_attr($name) . '" id="kallos_' . esc_attr($name) . '" maxlength="20" value="' . esc_attr($value) . '">'
            . '<select name="kallos_' . esc_attr($name) . '_system" aria-label="' . esc_attr($label) . '">' . $options . '</select></div></div>';
    }

    private function radios($name, array $options, $required = false) {
        $current = $this->values[$name] ?? '';
        $html = '<div class="choices"' . ($required ? ' data-kallos-group="' . esc_attr($name) . '"' : '') . '>';
        foreach ($options as $key => $label) {
            $html .= '<label class="check"><input type="radio" name="kallos_' . esc_attr($name) . '" value="' . esc_attr($key) . '"' . checked($key, $current, false) . '> ' . esc_html($label) . '</label>';
        }
        return $html . '</div>';
    }

    private function checks($name, array $options) {
        $current = [];
        if (in_array($name, ['interests', 'adult_interests'], true) && isset($this->values['interests'])) {
            $current = $this->values['interests'];
        } elseif (isset($this->values[$name]) && is_array($this->values[$name])) {
            $current = $this->values[$name];
        }
        $html = '<div class="choices">';
        foreach ($options as $key => $label) {
            $html .= '<label class="check"><input type="checkbox" name="kallos_' . esc_attr($name) . '[]" value="' . esc_attr($key) . '"' . checked(in_array($key, $current, true), true, false) . '> ' . esc_html($label) . '</label>';
        }
        return $html . '</div>';
    }

    // MARK: Block for the WordPress editor

    private function register_block() {
        if (!function_exists('register_block_type')) {
            return;
        }
        wp_register_script('kallos-model-form-block', false, ['wp-blocks', 'wp-element', 'wp-i18n'], self::VERSION, true);
        $label = esc_js(__('Kallos Model Form', self::TD));
        $note = esc_js(__('The model sign-up form shows here on your live page. Change what it asks in Settings › Kallos Model Form.', self::TD));
        wp_add_inline_script('kallos-model-form-block',
            '(function(b,e){if(!b||!e)return;b.registerBlockType("kallos/model-form",{title:"' . $label . '",icon:"id-alt",category:"widgets",supports:{html:false,multiple:false},'
            . 'edit:function(){return e.createElement("div",{style:{border:"1px dashed #999",borderRadius:"8px",padding:"16px"}},e.createElement("strong",null,"' . $label . '"),e.createElement("p",{style:{margin:"6px 0 0"}},"' . $note . '"));},'
            . 'save:function(){return null;}});})(window.wp&&wp.blocks,window.wp&&wp.element);');
        register_block_type('kallos/model-form', [
            'editor_script'   => 'kallos-model-form-block',
            'render_callback' => [$this, 'shortcode'],
        ]);
    }

    // MARK: Settings page

    public function settings_link($links) {
        array_unshift($links, '<a href="' . esc_url(admin_url('options-general.php?page=kallos-model-form')) . '">' . esc_html__('Settings', self::TD) . '</a>');
        return $links;
    }

    public function admin_menu() {
        add_options_page(__('Kallos Model Form', self::TD), __('Kallos Model Form', self::TD), 'manage_options', 'kallos-model-form', [$this, 'settings_page']);
    }

    public function register_settings() {
        register_setting('kallos_model_form', self::OPTION, [
            'type' => 'array',
            'sanitize_callback' => function ($input) {
                $input = is_array($input) ? $input : [];
                $show = [];
                foreach (self::SECTIONS as $section) {
                    $show[$section] = empty($input['show'][$section]) ? '' : '1';
                }
                $require = [];
                foreach (['measurements', 'social', 'interests', 'availability', 'suburb', 'address', 'experience', 'terms'] as $what) {
                    $require[$what] = empty($input['require'][$what]) ? '' : '1';
                }
                return [
                    'to'            => isset($input['to']) && is_email($input['to']) ? sanitize_email($input['to']) : '',
                    'studio'        => sanitize_text_field($input['studio'] ?? ''),
                    'country'       => sanitize_text_field($input['country'] ?? ''),
                    'unit'          => 'in' === ($input['unit'] ?? '') ? 'in' : 'cm',
                    'size_system'   => in_array($input['size_system'] ?? '', self::SIZE_SYSTEMS, true) ? $input['size_system'] : 'AU',
                    'show'          => $show,
                    'require'       => $require,
                    'heading'       => sanitize_text_field($input['heading'] ?? ''),
                    'intro'         => sanitize_textarea_field($input['intro'] ?? ''),
                    'address_search' => empty($input['address_search']) ? '' : '1',
                    'mapkit_token'  => preg_replace('/[^A-Za-z0-9._-]/', '', (string) ($input['mapkit_token'] ?? '')),
                    'require_fixed' => '1',
                    'consent'       => sanitize_textarea_field($input['consent'] ?? ''),
                    'thanks'        => sanitize_textarea_field($input['thanks'] ?? ''),
                    'button'        => sanitize_text_field($input['button'] ?? ''),
                    'privacy_url'   => esc_url_raw($input['privacy_url'] ?? ''),
                    'button_colour' => sanitize_hex_color($input['button_colour'] ?? '') ?: '#111111',
                ];
            },
        ]);
    }

    public function settings_page() {
        $saved = get_option(self::OPTION, []);
        $s = array_merge(self::defaults(), is_array($saved) ? $saved : []);
        $s['require'] = array_merge(self::defaults()['require'], is_array($s['require']) ? $s['require'] : []);
        if (is_array($saved) && empty($saved['require_fixed'])) {
            foreach (['address', 'experience', 'terms'] as $what) {
                $s['require'][$what] = '1';
            }
        }
        $n = esc_attr(self::OPTION);
        $text = function ($key, $label, $help = '', $type = 'text') use ($s, $n) {
            echo '<tr><th><label for="kmf_' . esc_attr($key) . '">' . esc_html($label) . '</label></th><td><input type="' . esc_attr($type) . '" class="regular-text" id="kmf_' . esc_attr($key) . '" name="' . $n . '[' . esc_attr($key) . ']" value="' . esc_attr($s[$key]) . '">'
                . ($help ? '<p class="description">' . esc_html($help) . '</p>' : '') . '</td></tr>';
        };
        $area = function ($key, $label, $help) use ($s, $n) {
            echo '<tr><th><label for="kmf_' . esc_attr($key) . '">' . esc_html($label) . '</label></th><td><textarea class="large-text" rows="2" id="kmf_' . esc_attr($key) . '" name="' . $n . '[' . esc_attr($key) . ']">' . esc_textarea($s[$key]) . '</textarea><p class="description">' . esc_html($help) . '</p></td></tr>';
        };
        $sections = [
            'address' => __('Where they live', self::TD), 'measurements' => __('Measurements and sizes', self::TD),
            'look' => __('Look (hair, eyes, tattoos, piercings)', self::TD), 'work' => __('Instagram, portfolio, agency, experience, kind of work', self::TD),
            'interests' => __('Kinds of shoots', self::TD), 'adult' => __('18+ section (comfort level, adults-only shoot types)', self::TD),
            'availability' => __('Availability', self::TD), 'travel' => __('Travel', self::TD), 'heard' => __('How they heard about you', self::TD),
            'message' => __('Free message', self::TD),
        ];
        $requires = [
            'address' => __('Full address (street, suburb, state, postcode and country)', self::TD),
            'suburb' => __('Suburb or city (when the full address isn\'t required)', self::TD), 'measurements' => __('Height and measurements', self::TD),
            'social' => __('Instagram or portfolio link', self::TD), 'interests' => __('At least one kind of shoot', self::TD),
            'availability' => __('Availability', self::TD),
            'experience' => __('Experience', self::TD), 'terms' => __('Kind of work (TFP, paid or both)', self::TD),
        ];

        echo '<div class="wrap"><h1>' . esc_html__('Kallos Model Form', self::TD) . '</h1>';
        echo '<p>' . wp_kses(__('Add the form to any page with the shortcode <code>[kallos_model_form]</code> (works in WPBakery, Elementor, Divi and the classic editor: put it in a text or shortcode element), or with the <strong>Kallos Model Form</strong> block. Each form sent is emailed to you with an <strong>Add to Kallos One</strong> button. Nothing is saved on this website.', self::TD), ['code' => [], 'strong' => []]) . '</p>';
        echo '<form method="post" action="options.php">';
        settings_fields('kallos_model_form');

        echo '<h2>' . esc_html__('Where forms go', self::TD) . '</h2><table class="form-table">';
        $text('to', __('Send forms to', self::TD), __('Empty = this site\'s admin email.', self::TD), 'email');
        $text('studio', __('Studio name', self::TD), __('Shown to models on the form and in the thank-you message. Empty = this site\'s name.', self::TD));
        echo '</table>';

        echo '<h2>' . esc_html__('Defaults for your country', self::TD) . '</h2><table class="form-table">';
        $text('country', __('Country filled in for models', self::TD), __('e.g. Australia, United Kingdom. Empty = models type their own.', self::TD));
        echo '<tr><th>' . esc_html__('Measurements shown first in', self::TD) . '</th><td><label><input type="radio" name="' . $n . '[unit]" value="cm"' . checked('cm', $s['unit'], false) . '> cm</label> &nbsp; <label><input type="radio" name="' . $n . '[unit]" value="in"' . checked('in', $s['unit'], false) . '> ' . esc_html__('inches', self::TD) . '</label><p class="description">' . esc_html__('Models can always switch.', self::TD) . '</p></td></tr>';
        echo '<tr><th>' . esc_html__('Size system shown first', self::TD) . '</th><td><select name="' . $n . '[size_system]">';
        foreach (self::SIZE_SYSTEMS as $sys) {
            echo '<option value="' . esc_attr($sys) . '"' . selected($sys, $s['size_system'], false) . '>' . esc_html($sys) . '</option>';
        }
        echo '</select></td></tr></table>';

        echo '<h2>' . esc_html__('What the form asks', self::TD) . '</h2>';
        echo '<p class="description">' . esc_html__('Name, email, mobile and date of birth are always asked and needed. Under-18s always need a parent or guardian, and never see the 18+ section.', self::TD) . '</p><table class="form-table"><tr><th>' . esc_html__('Show these sections', self::TD) . '</th><td>';
        foreach ($sections as $key => $label) {
            echo '<label style="display:block;margin:4px 0"><input type="checkbox" name="' . $n . '[show][' . esc_attr($key) . ']" value="1"' . checked(!empty($s['show'][$key]), true, false) . '> ' . esc_html($label) . '</label>';
        }
        echo '</td></tr><tr><th>' . esc_html__('Also required', self::TD) . '</th><td>';
        foreach ($requires as $key => $label) {
            echo '<label style="display:block;margin:4px 0"><input type="checkbox" name="' . $n . '[require][' . esc_attr($key) . ']" value="1"' . checked(!empty($s['require'][$key]), true, false) . '> ' . esc_html($label) . '</label>';
        }
        echo '<p class="description">' . esc_html__('Only applies when that section is shown.', self::TD) . '</p></td></tr>';
        echo '<tr><th>' . esc_html__('Address suggestions', self::TD) . '</th><td><label><input type="checkbox" name="' . $n . '[address_search]" value="1"' . checked(!empty($s['address_search']), true, false) . '> ' . esc_html__('Suggest addresses while the model types the street', self::TD) . '</label><p class="description">' . esc_html__('What the model types in the street box is sent to the address search below to find matches. The form says so under the box.', self::TD) . '</p></td></tr>';
        echo '<tr><th><label for="kmf_mapkit">' . esc_html__('Apple Maps token (recommended)', self::TD) . '</label></th><td><input type="text" class="large-text code" id="kmf_mapkit" name="' . $n . '[mapkit_token]" value="' . esc_attr($s['mapkit_token']) . '" autocomplete="off">'
            . '<p class="description">' . esc_html__('Paste a MapKit JS token to use Apple Maps, the same addresses as the Kallos One app. Make one in your Apple Developer account: Certificates, Identifiers & Profiles › Services › Maps › Configure › Tokens › +, Token Type MapKit JS, Restriction Domain, both forms of your website address separated by a comma (for example example.com, www.example.com), No Expiration. Free for normal use. Empty = OpenStreetMap (photon.komoot.io).', self::TD) . '</p></td></tr></table>';

        echo '<h2>' . esc_html__('Wording and look', self::TD) . '</h2><table class="form-table">';
        $text('heading', __('Heading', self::TD), __('Shown above the form. Empty = "Model Registration".', self::TD));
        $area('intro', __('Line under the heading', self::TD), __('Empty = the standard sentence: details are emailed only to your studio, never stored on this website and never shared or sold.', self::TD));
        $area('consent', __('Consent sentence', self::TD), __('Models tick this before sending. Empty = the standard sentence with your studio name.', self::TD));
        $text('privacy_url', __('Privacy page link', self::TD), __('Optional: a link to your privacy page, shown after the consent sentence.', self::TD), 'url');
        $area('thanks', __('Thank-you message', self::TD), __('Shown after sending. Empty = the standard message.', self::TD));
        $text('button', __('Button text', self::TD), __('Empty = "Send my details".', self::TD));
        echo '<tr><th><label for="kmf_colour">' . esc_html__('Button and tick colour', self::TD) . '</label></th><td><input type="color" id="kmf_colour" name="' . $n . '[button_colour]" value="' . esc_attr(self::colour($s['button_colour'])) . '"><p class="description">' . esc_html__('The button text turns black or white to stay readable.', self::TD) . '</p></td></tr>';
        echo '</table>';
        submit_button();
        echo '</form></div>';
    }
}

register_uninstall_hook(__FILE__, 'kallos_model_form_uninstall');
function kallos_model_form_uninstall() {
    delete_option('kallos_model_form');
}

Kallos_Model_Form::boot();
