=== Kallos One Client Enquiry Form ===
Contributors: kallosone
Tags: enquiry, booking, photographer, form, kallos one
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A client enquiry form for photographers. Each enquiry is emailed to you with an "Add to Kallos One" button. Nothing is saved on your website.

== Description ==

Clients who want to book a shoot tell you their name, email and phone, the kind of shoot, their preferred date (or that it's flexible), where, their budget, how they heard about you and a message, plus answers to up to six questions of your own. You get an email with everything, and an Add to Kallos One button that opens the Kallos One app (iPhone, iPad, Mac) with the enquiry filled in for you to check and save. Reply to the email and it goes straight to the client.

* Nothing is stored on your website: no database entries, no files.
* Works with any theme and page builder: shortcode [kallos_enquiry_form] (WPBakery Text Block, Elementor Shortcode widget, Divi Text/Code module, classic editor) or the Kallos Enquiry Form block.
* Settings › Kallos Enquiry Form: where enquiries go, studio name, kinds of shoot, your own questions, whether the phone number is required, which sections to show (location, budget, how they heard), thank-you message, button colour.
* Works alongside the Kallos One Model Form plugin.
* Spam protection without puzzles: a hidden field and a minimum time on the page.
* Translation-ready (text domain kallos-enquiry-form).

== Installation ==

1. Plugins › Add New › Upload Plugin, choose kallos-enquiry-form.zip, Install Now, Activate.
2. Settings › Kallos Enquiry Form: check the email address and your studio name, and add any questions you'd like to ask.
3. Add [kallos_enquiry_form] or the Kallos Enquiry Form block to a page.

== Privacy ==

* Nothing is stored on your website. The form's answers are emailed to you, and only to you.
* Clients tick "I agree to be contacted about my enquiry" before sending. When your site has a privacy policy page (Settings › Privacy), the form links to it.
* The Add to Kallos One button opens a small helper page on your website. The enquiry's details travel after the # in that link, which browsers never send to a server, so your website never sees or keeps them.

== Frequently Asked Questions ==

= The emails go to spam =
Your website sends them itself. Install a free SMTP plugin (for example FluentSMTP) so they're sent through your real email account.

== Changelog ==

= 1.0.0 =
* First release: client enquiry form with kinds of shoot, preferred date, location, budget, how they heard, message and up to six questions of your own, emailed with an Add to Kallos One button.
