<?php
/**
 * Plugin Name: Kallos One Client Enquiry Form
 * Description: A client enquiry form for photographers. Each enquiry is emailed to you with an "Add to Kallos One" button. Nothing is saved on the website.
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Made by a Professional Photographer
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: kallos-enquiry-form
 * Domain Path: /languages
 *
 * Add the form with the shortcode [kallos_enquiry_form] (works in every page builder) or the
 * "Kallos Enquiry Form" block. Settings › Kallos Enquiry Form sets where enquiries go and what they ask.
 */

if (!defined('ABSPATH')) {
    exit;
}

final class Kallos_Enquiry_Form {
    const VERSION = '1.0.0';
    const OPTION = 'kallos_enquiry_form';
    const TD = 'kallos-enquiry-form';
    const MIN_SECONDS = 4; // A person takes longer than this to fill in the form.
    const MAX_SECONDS = 7200; // A page left open longer than this is loaded again first.
    const MAX_PER_HOUR = 5; // Enquiries from one address in an hour.
    const MAX_QUESTIONS = 6;
    const MAX_KINDS = 30;
    /** Sections a photographer can show or hide. */
    const SECTIONS = ['location', 'budget', 'heard'];

    /** @var array<string,string> */
    private $errors = [];
    /** @var array<string,mixed> */
    private $values = [];

    public static function boot() {
        $self = new self();
        add_action('init', [$self, 'init']);
        add_action('template_redirect', [$self, 'maybe_helper_page'], 0);
        add_action('admin_menu', [$self, 'admin_menu']);
        add_action('admin_init', [$self, 'register_settings']);
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), [$self, 'settings_link']);
    }

    public function init() {
        load_plugin_textdomain(self::TD, false, dirname(plugin_basename(__FILE__)) . '/languages');
        add_shortcode('kallos_enquiry_form', [$this, 'shortcode']);
        $this->register_block();
        $this->maybe_handle();
    }

    // MARK: Settings

    private static function defaults() {
        return [
            'to'            => '',
            'studio'        => '',
            'button_colour' => '#111111',
            'thanks'        => '',
            'kinds'         => '',
            'questions'     => '',
            'require_phone' => '',
            'show'          => array_fill_keys(self::SECTIONS, '1'),
        ];
    }

    private static function default_kinds() {
        return [
            __('Portrait', self::TD), __('Family', self::TD), __('Wedding', self::TD), __('Event', self::TD),
            __('Engagement', self::TD), __('Maternity', self::TD), __('Newborn', self::TD), __('Headshots', self::TD),
            __('Brand / commercial', self::TD), __('Product', self::TD), __('Real estate', self::TD), __('Other', self::TD),
        ];
    }

    /** Clean, non-empty lines from a settings textarea, at most $max, each at most $chars long. */
    private static function lines($text, $max, $chars) {
        $out = [];
        foreach (preg_split('/\r\n|\r|\n/', (string) $text) as $line) {
            $line = mb_substr(trim(sanitize_text_field($line)), 0, $chars);
            if ('' !== $line && !in_array($line, $out, true)) {
                $out[] = $line;
            }
            if (count($out) >= $max) {
                break;
            }
        }
        return $out;
    }

    private function settings() {
        $saved = get_option(self::OPTION, []);
        $s = array_merge(self::defaults(), is_array($saved) ? $saved : []);
        $s['show'] = is_array($s['show']) ? $s['show'] : [];
        if ('' === $s['to']) {
            $s['to'] = get_option('admin_email');
        }
        if ('' === $s['studio']) {
            $s['studio'] = get_bloginfo('name');
        }
        if ('' === $s['thanks']) {
            /* translators: %s: the studio name */
            $s['thanks'] = sprintf(__('Thank you! Your enquiry has been sent to %s. We\'ll be in touch soon.', self::TD), $s['studio']);
        }
        $kinds = self::lines($s['kinds'], self::MAX_KINDS, 100);
        $s['kind_list'] = $kinds ?: self::default_kinds();
        $s['question_list'] = self::lines($s['questions'], self::MAX_QUESTIONS, 200);
        return $s;
    }

    private function shows($section) {
        $s = $this->settings();
        return !empty($s['show'][$section]);
    }

    // MARK: Fields

    /** Plain fields: name => [label, input type, section ('' = always shown)]. */
    private static function fields() {
        return [
            'name'     => [__('Your name', self::TD), 'text', ''],
            'email'    => [__('Email', self::TD), 'email', ''],
            'phone'    => [__('Phone', self::TD), 'tel', ''],
            'location' => [__('Where would you like the shoot?', self::TD), 'text', 'location'],
            'budget'   => [__('Budget (if you have one in mind)', self::TD), 'text', 'budget'],
            'heard'    => [__('How did you hear about us?', self::TD), 'text', 'heard'],
            'message'  => [__('Tell us about your shoot', self::TD), 'textarea', ''],
        ];
    }

    // MARK: Reading the form

    private static function post($name) {
        return isset($_POST['kallos_' . $name]) && !is_array($_POST['kallos_' . $name]) ? wp_unslash($_POST['kallos_' . $name]) : '';
    }

    public function maybe_handle() {
        if ('POST' !== ($_SERVER['REQUEST_METHOD'] ?? '') || empty($_POST['kallos_enquiry_form'])) {
            return;
        }
        // Spam checks: a hidden field people never fill in, and a minimum time on the page.
        if (!empty($_POST['kallos_website'])) {
            $this->errors['_form'] = __('Sorry, the form could not be sent.', self::TD);
            return;
        }
        $started = sanitize_text_field((string) self::post('started'));
        $parts = explode('.', $started);
        $age = time() - (int) ($parts[0] ?? 0);
        if (count($parts) !== 2 || !hash_equals(wp_hash($parts[0]), $parts[1]) || $age < self::MIN_SECONDS) {
            $this->errors['_form'] = __('Please take a moment to check your details, then send the form again.', self::TD);
        } elseif ($age > self::MAX_SECONDS) {
            $this->errors['_form'] = __('This page was open for a long time. Please reload it and send the form again.', self::TD);
        }
        // A few enquiries an hour from one address at most (the address itself is only hashed, and kept for an hour).
        $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
        $key = 'kallos_enq_' . substr(wp_hash($ip), 0, 20);
        $count = (int) get_transient($key);
        if ($count >= self::MAX_PER_HOUR) {
            $this->errors['_form'] = __('Too many enquiries were sent from here. Please try again later, or email us directly.', self::TD);
        }
        $settings = $this->settings();

        foreach (self::fields() as $name => $field) {
            if ('' !== $field[2] && !$this->shows($field[2])) {
                $this->values[$name] = '';
                continue;
            }
            $raw = self::post($name);
            if ('email' === $field[1]) {
                $value = sanitize_email($raw);
            } elseif ('textarea' === $field[1]) {
                $value = sanitize_textarea_field($raw);
            } else {
                $value = sanitize_text_field($raw);
            }
            $this->values[$name] = mb_substr($value, 0, 'message' === $name ? 2000 : 200);
        }
        $required = ['name', 'email'];
        if (!empty($settings['require_phone'])) {
            $required[] = 'phone';
        }
        foreach ($required as $name) {
            if ('' === $this->values[$name]) {
                /* translators: %s: a field name, e.g. "your name" */
                $this->errors[$name] = sprintf(__('Please fill in %s.', self::TD), mb_strtolower(self::fields()[$name][0]));
            }
        }
        if ('' === $this->values['email'] && '' !== trim((string) self::post('email'))) {
            $this->errors['email'] = __('Please check the email address.', self::TD);
        } elseif ('' !== $this->values['email'] && !is_email($this->values['email'])) {
            $this->errors['email'] = __('Please check the email address.', self::TD);
        }

        // Kind of shoot: only one of the choices set in Settings.
        $kind = mb_substr(sanitize_text_field(self::post('kind')), 0, 200);
        $this->values['kind'] = in_array($kind, $settings['kind_list'], true) ? $kind : '';

        // Preferred date: a real date, today or later.
        $date = sanitize_text_field(self::post('date'));
        $this->values['date'] = '';
        if ('' !== $date) {
            $d = DateTime::createFromFormat('!Y-m-d', $date, wp_timezone());
            if (!$d || $d->format('Y-m-d') !== $date) {
                $this->errors['date'] = __('Please check the date.', self::TD);
            } elseif ($date < wp_date('Y-m-d')) {
                $this->errors['date'] = __('Please choose a date from today on.', self::TD);
            } else {
                $this->values['date'] = $date;
            }
        }
        $this->values['flexible'] = !empty($_POST['kallos_flexible']);

        // The photographer's own questions (answers keep the question's number).
        $this->values['answers'] = [];
        foreach ($settings['question_list'] as $i => $question) {
            $answer = mb_substr(sanitize_textarea_field(self::post('a' . ($i + 1))), 0, 500);
            $this->values['answers'][$i + 1] = $answer;
        }

        if (empty($_POST['kallos_consent'])) {
            $this->errors['consent'] = __('Please agree to be contacted about your enquiry.', self::TD);
        }
        if ($this->errors) {
            return;
        }

        if ($this->send()) {
            set_transient($key, $count + 1, HOUR_IN_SECONDS);
            // Back to the page the form was on (the referrer can be missing in private browsers).
            $page = isset($_POST['kallos_back']) ? esc_url_raw(wp_unslash($_POST['kallos_back'])) : '';
            $back = wp_validate_redirect($page, '') ?: (wp_get_referer() ?: home_url('/'));
            wp_safe_redirect(add_query_arg('kallos_enquiry_sent', '1', remove_query_arg('kallos_enquiry_sent', $back)) . '#kallos-enquiry-form');
            exit;
        }
        $this->errors['_form'] = __('Sorry, the form could not be sent just now. Please try again later or email us directly.', self::TD);
    }

    // MARK: The email

    /** The site's own "Add to Kallos One" helper page. */
    private static function helper_url() {
        return add_query_arg('kallos_add_enquiry', '1', home_url('/'));
    }

    private function send() {
        $v = $this->values;
        $settings = $this->settings();
        // Line breaks never reach email headers (WordPress already strips them; this is belt and braces).
        $name = trim(preg_replace('/[\r\n\t]+/', ' ', $v['name']));
        $kind = trim(preg_replace('/[\r\n\t]+/', ' ', $v['kind']));

        // What goes in the Add to Kallos One link (Kallos One reads these names).
        $query = ['v' => '1'];
        foreach (['name', 'email', 'phone', 'kind', 'date'] as $field) {
            if ('' !== $v[$field]) {
                $query[$field] = $v[$field];
            }
        }
        if ($v['flexible']) {
            $query['flexible'] = '1';
        }
        foreach (['location', 'budget', 'heard', 'message'] as $field) {
            if ('' !== $v[$field]) {
                $query[$field] = $v[$field];
            }
        }
        foreach ($v['answers'] as $number => $answer) {
            if ('' !== $answer) {
                $query['q' . $number] = $settings['question_list'][$number - 1];
                $query['a' . $number] = $answer;
            }
        }
        $query['sent'] = wp_date('Y-m-d');
        // rawurlencode: spaces as %20, "+" kept as %2B (phone numbers). The details go after
        // the # sign, which browsers never send to the website.
        $pairs = [];
        foreach ($query as $key => $value) {
            $pairs[] = rawurlencode($key) . '=' . rawurlencode((string) $value);
        }
        $link = self::helper_url() . '#' . implode('&', $pairs);

        // What the email shows.
        $f = self::fields();
        $when = '';
        if ('' !== $v['date']) {
            $when = wp_date(get_option('date_format') ?: 'j F Y', strtotime($v['date'] . ' 12:00'));
            if ($v['flexible']) {
                $when .= ' (' . __('flexible', self::TD) . ')';
            }
        } elseif ($v['flexible']) {
            $when = __('Flexible', self::TD);
        }
        $shown = [
            [$f['name'][0], $v['name']],
            [$f['email'][0], $v['email']],
            [$f['phone'][0], $v['phone']],
            [__('Kind of shoot', self::TD), $v['kind']],
            [__('Preferred date', self::TD), $when],
            [$f['location'][0], $v['location']],
            [$f['budget'][0], $v['budget']],
            [$f['heard'][0], $v['heard']],
            [__('Message', self::TD), $v['message']],
        ];
        foreach ($v['answers'] as $number => $answer) {
            $shown[] = [$settings['question_list'][$number - 1], $answer];
        }

        $rows = '';
        $text = '';
        foreach ($shown as $pair) {
            list($label, $value) = $pair;
            if ('' === (string) $value) {
                continue;
            }
            $rows .= '<tr><td style="padding:6px 12px 6px 0;color:#6b655d;vertical-align:top">' . esc_html($label)
                . '</td><td style="padding:6px 0;vertical-align:top">' . nl2br(esc_html($value)) . '</td></tr>';
            $text .= $label . ': ' . $value . "\n";
        }
        $colour = self::colour($settings['button_colour']);
        $buttonText = self::text_on($colour);
        /* translators: %s: the client's name */
        $title = sprintf(__('New enquiry: %s', self::TD), $name);
        if ('' !== $kind) {
            $title .= ' · ' . $kind;
        }

        $html = '<div style="font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:15px;color:#1d1b18;max-width:560px">'
            . '<h2 style="margin:0 0 4px">' . esc_html($title) . '</h2>'
            /* translators: %s: the studio name */
            . '<p style="color:#6b655d;margin:0 0 16px">' . esc_html(sprintf(__('Sent from the enquiry form on %s.', self::TD), $settings['studio'])) . '</p>'
            . '<p><a href="' . esc_url($link) . '" style="display:inline-block;background:' . esc_attr($colour) . ';color:' . esc_attr($buttonText) . ';text-decoration:none;font-weight:600;padding:12px 20px;border-radius:10px">' . esc_html__('Add to Kallos One', self::TD) . '</a></p>'
            . '<p style="color:#6b655d;font-size:13px">' . esc_html__('Open this email on your iPhone, iPad or Mac with Kallos One installed, then tap the button. You check everything before it\'s saved.', self::TD) . '</p>'
            . '<table style="border-collapse:collapse;margin-top:12px">' . $rows . '</table>'
            . '</div>';
        $plain = $title . "\n\n" . __('Add to Kallos One:', self::TD) . "\n" . $link . "\n\n" . $text;

        $headers = ['Content-Type: text/html; charset=UTF-8'];
        if (is_email($v['email'])) {
            // Only plain name characters in the header's display name.
            $display = trim(preg_replace('/[^\p{L}\p{N} .\'-]+/u', '', $name));
            $headers[] = 'Reply-To: ' . ('' === $display ? '' : $display . ' ') . '<' . $v['email'] . '>';
        }
        // A plain-text copy for email apps that don't show HTML.
        $alt = function ($mailer) use ($plain) { $mailer->AltBody = $plain; };
        add_action('phpmailer_init', $alt);
        $sent = wp_mail($settings['to'], $title, $html, $headers);
        remove_action('phpmailer_init', $alt);
        return $sent;
    }

    private static function colour($value) {
        $c = sanitize_hex_color((string) $value);
        return $c ?: '#111111';
    }

    /** Black or white text, whichever reads better on the colour. */
    private static function text_on($hex) {
        $hex = ltrim($hex, '#');
        if (3 === strlen($hex)) {
            $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
        }
        $r = hexdec(substr($hex, 0, 2)); $g = hexdec(substr($hex, 2, 2)); $b = hexdec(substr($hex, 4, 2));
        return (0.299 * $r + 0.587 * $g + 0.114 * $b) > 160 ? '#111111' : '#ffffff';
    }

    // MARK: The helper page

    /** /?kallos_add_enquiry=1#… opens Kallos One with the details after the # (never sent here). */
    public function maybe_helper_page() {
        if (empty($_GET['kallos_add_enquiry'])) {
            return;
        }
        nocache_headers();
        header('Content-Type: text/html; charset=utf-8');
        header('X-Robots-Tag: noindex, nofollow');
        header('Referrer-Policy: no-referrer');
        $title = esc_html__('Add to Kallos One', self::TD);
        $intro = esc_html__('Opening Kallos One with this enquiry, ready for you to check and save.', self::TD);
        $none = esc_js(__('This link doesn\'t carry any details. Open it from the email your enquiry form sent you.', self::TD));
        $open = esc_html__('Open in Kallos One', self::TD);
        $note1 = esc_html__('Nothing is saved until you tap Save Enquiry in Kallos One. This page doesn\'t send or keep any details: they stay in your email and on your device.', self::TD);
        $note2 = esc_html__('Kallos One needs to be installed on this iPhone, iPad or Mac.', self::TD);
        $colour = esc_attr(self::colour($this->settings()['button_colour']));
        $textColour = esc_attr(self::text_on(self::colour($this->settings()['button_colour'])));
        echo '<!doctype html><html lang="' . esc_attr(get_bloginfo('language')) . '"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex, nofollow"><meta name="referrer" content="no-referrer"><title>' . $title . '</title>'
            . '<style>:root{--bg:#f6f3ee;--card:#fff;--ink:#1d1b18;--muted:#6b655d}@media(prefers-color-scheme:dark){:root{--bg:#141210;--card:#1f1c19;--ink:#f2ede6;--muted:#a39b90}}*{box-sizing:border-box}body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px 16px;background:var(--bg);color:var(--ink);font:16px/1.5 -apple-system,BlinkMacSystemFont,"Helvetica Neue",Arial,sans-serif}main{width:100%;max-width:440px;background:var(--card);border-radius:20px;padding:28px 24px;box-shadow:0 10px 30px rgba(0,0,0,.08)}h1{font-size:22px;margin:0 0 6px}p{margin:0 0 14px;color:var(--muted)}.who{font-size:18px;color:var(--ink);font-weight:600;margin:16px 0}a.b{display:block;text-align:center;text-decoration:none;background:' . $colour . ';color:' . $textColour . ';font-weight:600;padding:14px 18px;border-radius:14px;margin:18px 0 12px}.s{font-size:13px}</style></head>'
            . '<body><main><h1>' . $title . '</h1><p id="intro">' . $intro . '</p><div class="who" id="who"></div><a class="b" id="open" href="#">' . $open . '</a><p class="s">' . $note1 . '</p><p class="s">' . $note2 . '</p></main>'
            . '<script>(function(){var q=(location.hash||"").replace(/^#/,""),o=document.getElementById("open"),w=document.getElementById("who");'
            . 'if(!q){document.getElementById("intro").textContent="' . $none . '";o.style.display="none";return;}'
            . 'try{var p=new URLSearchParams(q),n=p.get("name");if(n)w.textContent=n;}catch(e){}'
            . 'var t="kallosone://add-enquiry?"+q;o.href=t;setTimeout(function(){window.location.href=t;},300);})();</script></body></html>';
        exit;
    }

    // MARK: The form

    public function shortcode() {
        $settings = $this->settings();
        $colour = self::colour($settings['button_colour']);
        $textColour = self::text_on($colour);
        ob_start();
        echo '<div class="kallos-ef" id="kallos-enquiry-form">';
        echo '<style>
            .kallos-ef{max-width:640px}
            .kallos-ef .row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
            @media(max-width:560px){.kallos-ef .row{grid-template-columns:1fr}}
            .kallos-ef label{display:block;font-size:14px;margin:10px 0 4px}
            .kallos-ef input[type=text],.kallos-ef input[type=email],.kallos-ef input[type=tel],.kallos-ef input[type=date],.kallos-ef select,.kallos-ef textarea{width:100%;padding:10px;border:1px solid #ccc;border-radius:8px;font-size:16px;box-sizing:border-box;background:#fff}
            .kallos-ef .err{color:#b42318 !important;font-size:13px;margin-top:2px}
            .kallos-ef .check{display:flex;gap:8px;align-items:flex-start;font-size:14px;margin:8px 0}
            .kallos-ef .check input{margin-top:4px}
            .kallos-ef .hp{position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden}
            .kallos-ef .ok{background:#e8f5ec;color:#1e5b33;border-radius:10px;padding:14px}
            .kallos-ef h3{margin:24px 0 4px}
            .kallos-ef .kallos-intro{font-size:15px;color:#4a453f;margin:0 0 14px}
            .kallos-ef .kallos-wait{font-size:13px;color:#6b655d;margin-top:6px}
            .kallos-ef .hint{font-size:13px;color:#6b655d}
            /* Themes and page builders restyle form controls; these win over them. */
            #kallos-enquiry-form input[type=checkbox]{-webkit-appearance:auto !important;appearance:auto !important;width:18px !important;height:18px !important;min-width:18px;margin:2px 0 0 0 !important;opacity:1 !important;accent-color:' . esc_attr($colour) . ' !important;position:relative !important;display:inline-block !important;border:0 !important;box-shadow:none !important}
            #kallos-enquiry-form input[type=checkbox]::before,#kallos-enquiry-form input[type=checkbox]::after{content:none !important;display:none !important}
            #kallos-enquiry-form label,#kallos-enquiry-form .check{color:#222 !important}
            #kallos-enquiry-form input[type=text],#kallos-enquiry-form input[type=email],#kallos-enquiry-form input[type=tel],#kallos-enquiry-form input[type=date],#kallos-enquiry-form select,#kallos-enquiry-form textarea{color:#111 !important;border:1px solid #bbb !important;background:#fff !important}
            #kallos-enquiry-form input[type=date]:invalid:not(:focus),#kallos-enquiry-form input[type=date]:invalid:not(:focus)::-webkit-datetime-edit{color:transparent !important}
            #kallos-enquiry-form button[type=submit]{background:' . esc_attr($colour) . ' !important;color:' . esc_attr($textColour) . ' !important;border:0 !important;border-radius:10px !important;padding:14px 26px !important;font-size:16px !important;font-weight:600 !important;opacity:1 !important;cursor:pointer !important;text-transform:none !important;letter-spacing:normal !important;box-shadow:none !important}
            #kallos-enquiry-form button[type=submit]:hover{filter:brightness(1.15)}
            #kallos-enquiry-form button[type=submit]:disabled{opacity:.45 !important;cursor:not-allowed !important;filter:none}
        </style>';

        if (isset($_GET['kallos_enquiry_sent']) && !$this->errors) {
            echo '<p class="ok">' . esc_html($settings['thanks']) . '</p></div>';
            return ob_get_clean();
        }
        /* translators: %s: the studio name */
        echo '<p class="kallos-intro">' . esc_html(sprintf(__('Your enquiry is emailed only to %s. Nothing is stored on this website.', self::TD), $settings['studio'])) . '</p>';
        if (!empty($this->errors['_form'])) {
            echo '<p class="err">' . esc_html($this->errors['_form']) . '</p>';
        } elseif ($this->errors) {
            echo '<p class="err">' . esc_html__('Please check the fields marked in red.', self::TD) . '</p>';
        }

        $now = (string) time();
        echo '<form method="post" action="#kallos-enquiry-form" novalidate>';
        echo '<input type="hidden" name="kallos_enquiry_form" value="1">';
        $here = (is_ssl() ? 'https://' : 'http://') . sanitize_text_field(wp_unslash($_SERVER['HTTP_HOST'] ?? '')) . esc_url_raw(wp_unslash($_SERVER['REQUEST_URI'] ?? '/'));
        echo '<input type="hidden" name="kallos_back" value="' . esc_attr(remove_query_arg('kallos_enquiry_sent', $here)) . '">';
        echo '<input type="hidden" name="kallos_started" value="' . esc_attr($now . '.' . wp_hash($now)) . '">';
        echo '<div class="hp" aria-hidden="true"><label>Website<input type="text" name="kallos_website" tabindex="-1" autocomplete="off"></label></div>';
        echo '<p class="hint">' . esc_html__('Fields marked * are needed.', self::TD) . '</p>';

        echo '<h3>' . esc_html__('About you', self::TD) . '</h3>';
        echo $this->input('name', 'name', true);
        echo '<div class="row">' . $this->input('email', 'email', true) . $this->input('phone', 'tel', !empty($settings['require_phone'])) . '</div>';

        echo '<h3>' . esc_html__('Your shoot', self::TD) . '</h3>';
        $kind = $this->values['kind'] ?? '';
        echo '<div><label for="kallos_kind">' . esc_html__('What kind of shoot?', self::TD) . '</label><select name="kallos_kind" id="kallos_kind">';
        echo '<option value="">' . esc_html__('Choose…', self::TD) . '</option>';
        foreach ($settings['kind_list'] as $option) {
            echo '<option value="' . esc_attr($option) . '"' . selected($option, $kind, false) . '>' . esc_html($option) . '</option>';
        }
        echo '</select>' . $this->error('kind') . '</div>';
        echo '<div class="row"><div><label for="kallos_date">' . esc_html__('Preferred date', self::TD) . '</label>'
            . '<input type="date" name="kallos_date" id="kallos_date" min="' . esc_attr(wp_date('Y-m-d')) . '" value="' . esc_attr($this->values['date'] ?? '') . '"' . (!empty($this->errors['date']) ? ' aria-invalid="true" aria-describedby="kallos_date_err"' : '') . '>'
            . $this->error('date') . '</div>'
            . '<div><label class="check" style="margin-top:38px"><input type="checkbox" name="kallos_flexible" value="1"' . checked(!empty($this->values['flexible']), true, false) . '> ' . esc_html__('My date is flexible', self::TD) . '</label></div></div>';
        if ($this->shows('location')) {
            echo $this->input('location', 'off');
        }
        if ($this->shows('budget')) {
            echo $this->input('budget', 'off');
        }
        if ($this->shows('heard')) {
            echo $this->input('heard', 'off');
        }
        echo $this->input('message', 'off');

        if ($settings['question_list']) {
            echo '<h3>' . esc_html__('A few questions', self::TD) . '</h3>';
            foreach ($settings['question_list'] as $i => $question) {
                $id = 'kallos_a' . ($i + 1);
                echo '<div><label for="' . esc_attr($id) . '">' . esc_html($question) . '</label>'
                    . '<textarea name="' . esc_attr($id) . '" id="' . esc_attr($id) . '" rows="3" maxlength="500">' . esc_textarea($this->values['answers'][$i + 1] ?? '') . '</textarea></div>';
            }
        }

        $consent = esc_html__('I agree to be contacted about my enquiry', self::TD);
        $privacy = function_exists('get_privacy_policy_url') ? get_privacy_policy_url() : '';
        if ('' !== $privacy) {
            $consent .= ' (<a href="' . esc_url($privacy) . '" target="_blank" rel="noopener">' . esc_html__('Privacy policy', self::TD) . '</a>)';
        }
        echo '<label class="check"><input type="checkbox" name="kallos_consent" value="1" required' . checked(!empty($_POST['kallos_consent']), true, false) . (!empty($this->errors['consent']) ? ' aria-invalid="true" aria-describedby="kallos_consent_err"' : '') . '> <span>' . $consent . ' <span aria-hidden="true">*</span></span></label>';
        echo $this->error('consent');
        if ($this->errors) {
            echo '<p class="err">' . esc_html(!empty($this->errors['_form']) ? $this->errors['_form'] : __('Something is missing: please check the fields marked in red above.', self::TD)) . '</p>';
        }
        echo '<p><button type="submit" id="kallos-enquiry-send">' . esc_html__('Send my enquiry', self::TD) . '</button></p>';
        echo '<p class="kallos-wait" id="kallos-enquiry-wait" style="display:none">' . esc_html__('Fill in everything marked * to send.', self::TD) . '</p>';
        echo '</form>';
        // The button works only when everything needed is filled in (the server checks again).
        echo '<script>(function(){var f=document.getElementById("kallos-enquiry-form");if(!f)return;'
            . 'var b=document.getElementById("kallos-enquiry-send"),w=document.getElementById("kallos-enquiry-wait"),em=/^[^ @]+@[^ @]+[.][^ @]+$/;'
            . 'function ok(){var good=true;f.querySelectorAll("input[required],select[required],textarea[required]").forEach(function(e){if(e.type==="checkbox"){if(!e.checked)good=false;}else if(!e.value.trim()){good=false;}else if(e.type==="email"&&!em.test(e.value.trim())){good=false;}});return good;}'
            . 'function check(){if(!b)return;var g=ok();b.disabled=!g;if(w)w.style.display=g?"none":"";}'
            . 'f.addEventListener("input",check);f.addEventListener("change",function(){setTimeout(check,0);});check();'
            . '})();</script>';
        echo '</div>';
        return ob_get_clean();
    }

    private function error($name) {
        return !empty($this->errors[$name]) ? '<div class="err" id="kallos_' . esc_attr($name) . '_err">' . esc_html($this->errors[$name]) . '</div>' : '';
    }

    private function input($name, $autocomplete, $required = false) {
        $field = self::fields()[$name];
        $label = esc_html($field[0]) . ($required ? ' <span aria-hidden="true">*</span>' : '');
        $value = $this->values[$name] ?? '';
        $attrs = 'name="kallos_' . esc_attr($name) . '" id="kallos_' . esc_attr($name) . '" autocomplete="' . esc_attr($autocomplete) . '"' . ($required ? ' required aria-required="true"' : '');
        if (!empty($this->errors[$name])) {
            $attrs .= ' aria-invalid="true" aria-describedby="kallos_' . esc_attr($name) . '_err"';
        }
        if ('textarea' === $field[1]) {
            $control = '<textarea ' . $attrs . ' rows="5" maxlength="2000">' . esc_textarea($value) . '</textarea>';
        } else {
            $control = '<input type="' . esc_attr($field[1]) . '" ' . $attrs . ' maxlength="200" value="' . esc_attr($value) . '">';
        }
        return '<div><label for="kallos_' . esc_attr($name) . '">' . $label . '</label>' . $control . $this->error($name) . '</div>';
    }

    // MARK: Block for the WordPress editor

    private function register_block() {
        if (!function_exists('register_block_type')) {
            return;
        }
        wp_register_script('kallos-enquiry-form-block', false, ['wp-blocks', 'wp-element', 'wp-i18n'], self::VERSION, true);
        $label = esc_js(__('Kallos Enquiry Form', self::TD));
        $note = esc_js(__('The client enquiry form shows here on your live page. Change what it asks in Settings › Kallos Enquiry Form.', self::TD));
        wp_add_inline_script('kallos-enquiry-form-block',
            '(function(b,e){if(!b||!e)return;b.registerBlockType("kallos/enquiry-form",{title:"' . $label . '",icon:"email-alt",category:"widgets",supports:{html:false,multiple:false},'
            . 'edit:function(){return e.createElement("div",{style:{border:"1px dashed #999",borderRadius:"8px",padding:"16px"}},e.createElement("strong",null,"' . $label . '"),e.createElement("p",{style:{margin:"6px 0 0"}},"' . $note . '"));},'
            . 'save:function(){return null;}});})(window.wp&&wp.blocks,window.wp&&wp.element);');
        register_block_type('kallos/enquiry-form', [
            'editor_script'   => 'kallos-enquiry-form-block',
            'render_callback' => [$this, 'shortcode'],
        ]);
    }

    // MARK: Settings page

    public function settings_link($links) {
        array_unshift($links, '<a href="' . esc_url(admin_url('options-general.php?page=kallos-enquiry-form')) . '">' . esc_html__('Settings', self::TD) . '</a>');
        return $links;
    }

    public function admin_menu() {
        add_options_page(__('Kallos Enquiry Form', self::TD), __('Kallos Enquiry Form', self::TD), 'manage_options', 'kallos-enquiry-form', [$this, 'settings_page']);
    }

    public function register_settings() {
        register_setting('kallos_enquiry_form', self::OPTION, [
            'type' => 'array',
            'sanitize_callback' => function ($input) {
                $input = is_array($input) ? $input : [];
                $show = [];
                foreach (self::SECTIONS as $section) {
                    $show[$section] = empty($input['show'][$section]) ? '' : '1';
                }
                return [
                    'to'            => isset($input['to']) && is_email($input['to']) ? sanitize_email($input['to']) : '',
                    'studio'        => sanitize_text_field($input['studio'] ?? ''),
                    'button_colour' => sanitize_hex_color($input['button_colour'] ?? '') ?: '#111111',
                    'thanks'        => sanitize_textarea_field($input['thanks'] ?? ''),
                    'kinds'         => implode("\n", self::lines($input['kinds'] ?? '', self::MAX_KINDS, 100)),
                    'questions'     => implode("\n", self::lines($input['questions'] ?? '', self::MAX_QUESTIONS, 200)),
                    'require_phone' => empty($input['require_phone']) ? '' : '1',
                    'show'          => $show,
                ];
            },
        ]);
    }

    public function settings_page() {
        $saved = get_option(self::OPTION, []);
        $s = array_merge(self::defaults(), is_array($saved) ? $saved : []);
        $n = esc_attr(self::OPTION);
        $text = function ($key, $label, $help = '', $type = 'text') use ($s, $n) {
            echo '<tr><th><label for="kef_' . esc_attr($key) . '">' . esc_html($label) . '</label></th><td><input type="' . esc_attr($type) . '" class="regular-text" id="kef_' . esc_attr($key) . '" name="' . $n . '[' . esc_attr($key) . ']" value="' . esc_attr($s[$key]) . '">'
                . ($help ? '<p class="description">' . esc_html($help) . '</p>' : '') . '</td></tr>';
        };
        $area = function ($key, $label, $help, $rows = 2, $placeholder = '') use ($s, $n) {
            echo '<tr><th><label for="kef_' . esc_attr($key) . '">' . esc_html($label) . '</label></th><td><textarea class="large-text" rows="' . (int) $rows . '" id="kef_' . esc_attr($key) . '" name="' . $n . '[' . esc_attr($key) . ']" placeholder="' . esc_attr($placeholder) . '">' . esc_textarea($s[$key]) . '</textarea><p class="description">' . esc_html($help) . '</p></td></tr>';
        };
        $sections = [
            'location' => __('Where the shoot is', self::TD),
            'budget'   => __('Budget', self::TD),
            'heard'    => __('How they heard about you', self::TD),
        ];

        echo '<div class="wrap"><h1>' . esc_html__('Kallos Enquiry Form', self::TD) . '</h1>';
        echo '<p>' . wp_kses(__('Add the form to any page with the shortcode <code>[kallos_enquiry_form]</code> (works in WPBakery, Elementor, Divi and the classic editor: put it in a text or shortcode element), or with the <strong>Kallos Enquiry Form</strong> block. Each enquiry is emailed to you with an <strong>Add to Kallos One</strong> button. Nothing is saved on this website.', self::TD), ['code' => [], 'strong' => []]) . '</p>';
        echo '<form method="post" action="options.php">';
        settings_fields('kallos_enquiry_form');

        echo '<h2>' . esc_html__('Where enquiries go', self::TD) . '</h2><table class="form-table">';
        $text('to', __('Send enquiries to', self::TD), __('Empty = this site\'s admin email.', self::TD), 'email');
        $text('studio', __('Studio name', self::TD), __('Shown to clients on the form and in the thank-you message. Empty = this site\'s name.', self::TD));
        echo '</table>';

        echo '<h2>' . esc_html__('What the form asks', self::TD) . '</h2>';
        echo '<p class="description">' . esc_html__('Name and email are always asked and needed. Kind of shoot, preferred date and a message are always asked.', self::TD) . '</p><table class="form-table">';
        echo '<tr><th>' . esc_html__('Phone', self::TD) . '</th><td><label><input type="checkbox" name="' . $n . '[require_phone]" value="1"' . checked(!empty($s['require_phone']), true, false) . '> ' . esc_html__('Phone number is required', self::TD) . '</label></td></tr>';
        echo '<tr><th>' . esc_html__('Show these sections', self::TD) . '</th><td>';
        foreach ($sections as $key => $label) {
            echo '<label style="display:block;margin:4px 0"><input type="checkbox" name="' . $n . '[show][' . esc_attr($key) . ']" value="1"' . checked(!empty($s['show'][$key]), true, false) . '> ' . esc_html($label) . '</label>';
        }
        echo '</td></tr>';
        $area('kinds', __('Kinds of shoot', self::TD), sprintf(
            /* translators: %d: the most choices allowed */
            __('One per line, shown in the "What kind of shoot?" list (up to %d). Empty = the standard list shown here in grey.', self::TD), self::MAX_KINDS),
            8, implode("\n", self::default_kinds()));
        $area('questions', __('Your questions', self::TD), sprintf(
            /* translators: %d: the most questions allowed */
            __('Optional: up to %d extra questions, one per line. Each gets its own answer box; clients can leave them empty.', self::TD), self::MAX_QUESTIONS),
            6);
        echo '</table>';

        echo '<h2>' . esc_html__('Wording and look', self::TD) . '</h2><table class="form-table">';
        $area('thanks', __('Thank-you message', self::TD), __('Shown after sending. Empty = the standard message.', self::TD));
        echo '<tr><th><label for="kef_colour">' . esc_html__('Button and tick colour', self::TD) . '</label></th><td><input type="color" id="kef_colour" name="' . $n . '[button_colour]" value="' . esc_attr(self::colour($s['button_colour'])) . '"><p class="description">' . esc_html__('The button text turns black or white to stay readable.', self::TD) . '</p></td></tr>';
        echo '</table>';
        submit_button();
        echo '</form></div>';
    }
}

register_uninstall_hook(__FILE__, 'kallos_enquiry_form_uninstall');
function kallos_enquiry_form_uninstall() {
    delete_option('kallos_enquiry_form');
}

Kallos_Enquiry_Form::boot();
